import { Variants } from 'framer-motion'

/* ─── Base Easings ───────────────────────────────────────────── */
export const easings = {
  smooth: [0.25, 0.46, 0.45, 0.94],
  spring: [0.34, 1.56, 0.64, 1],
  snappy: [0.4, 0, 0.2, 1],
  expo: [0.16, 1, 0.3, 1],
}

/* ─── Fade Variants ──────────────────────────────────────────── */
export const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: easings.smooth },
  },
}

export const fadeInDown: Variants = {
  hidden: { opacity: 0, y: -30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: easings.smooth },
  },
}

export const fadeIn: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { duration: 0.5 },
  },
}

export const fadeInLeft: Variants = {
  hidden: { opacity: 0, x: -40 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.7, ease: easings.smooth },
  },
}

export const fadeInRight: Variants = {
  hidden: { opacity: 0, x: 40 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.7, ease: easings.smooth },
  },
}

export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.88 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: { duration: 0.6, ease: easings.expo },
  },
}

/* ─── Container (stagger children) ──────────────────────────── */
export const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
      delayChildren: 0.1,
    },
  },
}

export const staggerContainerFast: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.07,
      delayChildren: 0.05,
    },
  },
}

export const staggerContainerSlow: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.18,
      delayChildren: 0.2,
    },
  },
}

/* ─── Card Hover ─────────────────────────────────────────────── */
export const cardHover = {
  rest: { scale: 1, y: 0, transition: { duration: 0.3, ease: easings.smooth } },
  hover: { scale: 1.02, y: -6, transition: { duration: 0.3, ease: easings.smooth } },
}

export const cardHoverSubtle = {
  rest: { scale: 1, y: 0, transition: { duration: 0.25, ease: easings.smooth } },
  hover: { scale: 1.01, y: -3, transition: { duration: 0.25, ease: easings.smooth } },
}

/* ─── Button ─────────────────────────────────────────────────── */
export const buttonTap = {
  tap: { scale: 0.97 },
}

/* ─── Slide Reveal ───────────────────────────────────────────── */
export const slideReveal: Variants = {
  hidden: { scaleX: 1, transformOrigin: 'left' },
  visible: {
    scaleX: 0,
    transition: { duration: 0.7, ease: easings.expo },
  },
}

/* ─── Word / char animations ──────────────────────────────────── */
export const wordReveal: Variants = {
  hidden: { opacity: 0, y: '100%' },
  visible: {
    opacity: 1,
    y: '0%',
    transition: { duration: 0.5, ease: easings.expo },
  },
}

export const charReveal: Variants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.4, ease: easings.expo },
  },
}

/* ─── Menu animations ─────────────────────────────────────────── */
export const menuOpen: Variants = {
  hidden: { opacity: 0, x: '100%' },
  visible: {
    opacity: 1,
    x: '0%',
    transition: { duration: 0.4, ease: easings.smooth },
  },
  exit: {
    opacity: 0,
    x: '100%',
    transition: { duration: 0.3, ease: easings.smooth },
  },
}

export const menuItem: Variants = {
  hidden: { opacity: 0, x: 30 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.4, ease: easings.smooth },
  },
}

/* ─── Number counter ─────────────────────────────────────────── */
export const countUp = (from: number, to: number, duration = 2) => ({
  from,
  to,
  duration,
  ease: 'easeOut' as const,
})
