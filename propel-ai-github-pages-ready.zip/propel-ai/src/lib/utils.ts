import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

/* ─── cn utility (clsx + tailwind-merge) ────────────────────── */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/* ─── Format large numbers ───────────────────────────────────── */
export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`
  return n.toString()
}

/* ─── Clamp ──────────────────────────────────────────────────── */
export function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max)
}

/* ─── Sleep ──────────────────────────────────────────────────── */
export const sleep = (ms: number) =>
  new Promise((resolve) => setTimeout(resolve, ms))

/* ─── Debounce ───────────────────────────────────────────────── */
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>
  return (...args) => {
    clearTimeout(timer)
    timer = setTimeout(() => fn(...args), delay)
  }
}
