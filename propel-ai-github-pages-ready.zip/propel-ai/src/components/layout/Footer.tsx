import Link from 'next/link'
import { Zap, Twitter, Linkedin, Github, Mail, ArrowUpRight } from 'lucide-react'

const footerLinks = {
  Services: [
    { label: 'AI Automation', href: '/services' },
    { label: 'AI Chatbots', href: '/services' },
    { label: 'CRM Automation', href: '/services' },
    { label: 'Lead Generation', href: '/services' },
    { label: 'AI Voice Agents', href: '/services' },
    { label: 'Email Automation', href: '/services' },
  ],
  Company: [
    { label: 'About Us', href: '/about' },
    { label: 'Contact', href: '/contact' },
    { label: 'Careers', href: '/contact' },
    { label: 'Blog', href: '#' },
    { label: 'Case Studies', href: '#' },
  ],
  Resources: [
    { label: 'Documentation', href: '#' },
    { label: 'API Reference', href: '#' },
    { label: 'Status', href: '#' },
    { label: 'Changelog', href: '#' },
  ],
}

const socials = [
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Github, href: '#', label: 'GitHub' },
  { icon: Mail, href: 'mailto:hello@propelai.agency', label: 'Email' },
]

export function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="relative mt-24 border-t border-white/[0.06] overflow-hidden">
      {/* Gradient top glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[2px] opacity-60"
        style={{
          background: 'linear-gradient(90deg, transparent, #3b82f6, #8b5cf6, transparent)',
        }}
      />

      {/* Background glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] opacity-[0.05]"
        style={{
          background: 'radial-gradient(ellipse, #3b82f6, transparent)',
          filter: 'blur(60px)',
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6 py-16">
        {/* Top section */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 pb-12 border-b border-white/[0.06]">
          {/* Brand column */}
          <div className="lg:col-span-2">
            <Link href="/" className="inline-flex items-center gap-2.5 mb-5 group">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center shadow-glow-blue">
                <Zap size={18} className="text-white fill-white" />
              </div>
              <span className="font-display text-[1.1rem] font-700 tracking-tight">
                <span className="gradient-text">Propel</span>
                <span className="text-white"> AI</span>
              </span>
            </Link>

            <p className="text-slate-400 text-sm leading-relaxed max-w-xs mb-6">
              Elite AI automation agency helping fast-growing businesses automate
              operations, deploy intelligent agents, and eliminate repetitive work
              — at scale.
            </p>

            {/* Social links */}
            <div className="flex items-center gap-2">
              {socials.map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="w-9 h-9 flex items-center justify-center rounded-xl bg-white/[0.04] border border-white/[0.07] text-slate-400 hover:text-white hover:bg-white/[0.08] hover:border-white/[0.15] transition-all duration-200"
                >
                  <Icon size={15} />
                </a>
              ))}
            </div>

            {/* Contact */}
            <div className="mt-6 flex items-center gap-2 text-sm text-slate-500">
              <Mail size={13} />
              <a
                href="mailto:hello@propelai.agency"
                className="hover:text-blue-400 transition-colors duration-200"
              >
                hello@propelai.agency
              </a>
            </div>
          </div>

          {/* Links columns */}
          <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-3 gap-8">
            {Object.entries(footerLinks).map(([heading, links]) => (
              <div key={heading}>
                <h3 className="text-white text-sm font-display font-600 mb-4 tracking-wide">
                  {heading}
                </h3>
                <ul className="flex flex-col gap-2.5">
                  {links.map((link) => (
                    <li key={link.label}>
                      <Link
                        href={link.href}
                        className="text-slate-400 text-sm hover:text-white transition-colors duration-200 flex items-center gap-1 group"
                      >
                        {link.label}
                        {link.href === '#' && (
                          <ArrowUpRight
                            size={12}
                            className="opacity-0 group-hover:opacity-70 transition-opacity duration-200"
                          />
                        )}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-slate-600 text-xs font-body">
            © {year} Propel AI. All rights reserved.
          </p>
          <div className="flex items-center gap-5">
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map((item) => (
              <a
                key={item}
                href="#"
                className="text-slate-600 hover:text-slate-400 text-xs transition-colors duration-200"
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
