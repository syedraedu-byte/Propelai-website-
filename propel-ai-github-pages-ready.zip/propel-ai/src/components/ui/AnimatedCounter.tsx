'use client'

import { useEffect, useRef, useState } from 'react'
import { useInView, animate } from 'framer-motion'
import { cn } from '@/lib/utils'

interface AnimatedCounterProps {
  from?: number
  to: number
  duration?: number
  prefix?: string
  suffix?: string
  className?: string
  decimals?: number
  delay?: number
}

export function AnimatedCounter({
  from = 0,
  to,
  duration = 2,
  prefix = '',
  suffix = '',
  className,
  decimals = 0,
  delay = 0,
}: AnimatedCounterProps) {
  const ref = useRef<HTMLSpanElement>(null)
  const inViewRef = useRef<HTMLSpanElement>(null)
  const isInView = useInView(inViewRef, { once: true, margin: '-80px' })
  const [hasAnimated, setHasAnimated] = useState(false)

  useEffect(() => {
    if (!isInView || hasAnimated || !ref.current) return

    setHasAnimated(true)

    const timer = setTimeout(() => {
      const controls = animate(from, to, {
        duration,
        ease: 'easeOut',
        onUpdate(value) {
          if (ref.current) {
            ref.current.textContent =
              prefix + value.toFixed(decimals) + suffix
          }
        },
      })
      return () => controls.stop()
    }, delay * 1000)

    return () => clearTimeout(timer)
  }, [isInView, hasAnimated, from, to, duration, prefix, suffix, decimals, delay])

  return (
    <span ref={inViewRef}>
      <span ref={ref} className={cn('tabular-nums', className)}>
        {prefix}
        {from.toFixed(decimals)}
        {suffix}
      </span>
    </span>
  )
}
