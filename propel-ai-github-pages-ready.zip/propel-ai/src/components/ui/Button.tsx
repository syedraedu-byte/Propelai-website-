'use client'

import { forwardRef } from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'glow'
type ButtonSize = 'sm' | 'md' | 'lg' | 'xl'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant
  size?: ButtonSize
  children: React.ReactNode
  asChild?: boolean
  href?: string
  icon?: React.ReactNode
  iconPosition?: 'left' | 'right'
  loading?: boolean
  glow?: boolean
}

const variants: Record<ButtonVariant, string> = {
  primary: [
    'relative bg-blue-500 hover:bg-blue-600 text-white font-semibold',
    'shadow-[0_0_20px_rgba(59,130,246,0.35)] hover:shadow-[0_0_35px_rgba(59,130,246,0.5)]',
    'border border-blue-500/50',
    'before:absolute before:inset-0 before:rounded-inherit before:bg-gradient-to-b before:from-white/10 before:to-transparent before:pointer-events-none',
  ].join(' '),
  secondary: [
    'bg-white/[0.06] hover:bg-white/[0.1] text-white font-semibold',
    'border border-white/[0.1] hover:border-white/[0.2]',
    'backdrop-blur-sm',
  ].join(' '),
  ghost: [
    'text-slate-300 hover:text-white hover:bg-white/[0.05] font-medium',
  ].join(' '),
  outline: [
    'border border-blue-500/40 hover:border-blue-500/80 text-blue-400 hover:text-blue-300 font-semibold',
    'hover:bg-blue-500/[0.06]',
  ].join(' '),
  glow: [
    'relative text-white font-semibold',
    'bg-gradient-to-r from-blue-600 via-violet-600 to-purple-600',
    'bg-[length:200%_auto] hover:bg-right-bottom transition-all duration-500',
    'shadow-[0_0_30px_rgba(99,102,241,0.4)] hover:shadow-[0_0_50px_rgba(99,102,241,0.6)]',
    'border border-white/10',
  ].join(' '),
}

const sizes: Record<ButtonSize, string> = {
  sm: 'px-4 py-2 text-sm rounded-xl gap-1.5',
  md: 'px-5 py-2.5 text-sm rounded-xl gap-2',
  lg: 'px-7 py-3.5 text-base rounded-2xl gap-2.5',
  xl: 'px-9 py-4.5 text-lg rounded-2xl gap-3',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = 'primary',
      size = 'md',
      children,
      className,
      icon,
      iconPosition = 'right',
      loading = false,
      glow = false,
      href,
      ...props
    },
    ref
  ) => {
    const classes = cn(
      'inline-flex items-center justify-center transition-all duration-200 select-none focus-visible:outline-none',
      'disabled:opacity-50 disabled:cursor-not-allowed',
      variants[variant],
      sizes[size],
      glow && variant !== 'glow' && 'shadow-glow-blue',
      className
    )

    const content = (
      <>
        {loading && (
          <svg
            className="animate-spin h-4 w-4"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              className="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              strokeWidth="4"
            />
            <path
              className="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
            />
          </svg>
        )}
        {icon && iconPosition === 'left' && !loading && (
          <span className="shrink-0">{icon}</span>
        )}
        <span>{children}</span>
        {icon && iconPosition === 'right' && !loading && (
          <span className="shrink-0">{icon}</span>
        )}
      </>
    )

    if (href) {
      return (
        <motion.a
          href={href}
          className={classes}
          whileTap={{ scale: 0.97 }}
          whileHover={{ scale: 1.02 }}
        >
          {content}
        </motion.a>
      )
    }

    return (
      <motion.button
        ref={ref}
        className={classes}
        whileTap={{ scale: 0.97 }}
        whileHover={{ scale: variant === 'ghost' ? 1 : 1.02 }}
        {...(props as React.ComponentPropsWithoutRef<typeof motion.button>)}
      >
        {content}
      </motion.button>
    )
  }
)

Button.displayName = 'Button'
