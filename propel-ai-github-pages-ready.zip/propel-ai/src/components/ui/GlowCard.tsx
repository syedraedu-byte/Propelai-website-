'use client'

import { useRef, MouseEvent } from 'react'
import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'

interface GlowCardProps {
  children: React.ReactNode
  className?: string
  glowColor?: string
  hover?: boolean
  gradient?: boolean
}

export function GlowCard({
  children,
  className,
  glowColor = 'rgba(59,130,246,0.15)',
  hover = true,
  gradient = false,
}: GlowCardProps) {
  const cardRef = useRef<HTMLDivElement>(null)

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current || !hover) return
    const rect = cardRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    cardRef.current.style.setProperty('--mouse-x', `${x}px`)
    cardRef.current.style.setProperty('--mouse-y', `${y}px`)
    cardRef.current.style.setProperty('--glow-color', glowColor)
  }

  const handleMouseLeave = () => {
    if (!cardRef.current) return
    cardRef.current.style.removeProperty('--mouse-x')
    cardRef.current.style.removeProperty('--mouse-y')
  }

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={cn(
        'relative rounded-2xl overflow-hidden',
        'bg-[rgba(255,255,255,0.025)]',
        'border border-white/[0.07]',
        hover && [
          'transition-all duration-300 cursor-default',
          'hover:border-blue-500/30',
          'hover:shadow-[0_0_30px_rgba(59,130,246,0.12)]',
          // Mouse-follow glow via CSS variable
          'before:absolute before:inset-0 before:rounded-2xl before:opacity-0 hover:before:opacity-100',
          'before:transition-opacity before:duration-300 before:pointer-events-none',
          'before:bg-[radial-gradient(400px_circle_at_var(--mouse-x,50%)_var(--mouse-y,50%),var(--glow-color,rgba(59,130,246,0.1)),transparent_70%)]',
        ],
        gradient && 'gradient-border',
        className
      )}
    >
      {children}
    </motion.div>
  )
}
