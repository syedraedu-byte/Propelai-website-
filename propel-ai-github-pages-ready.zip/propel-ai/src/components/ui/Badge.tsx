import { cn } from '@/lib/utils'

type BadgeVariant = 'blue' | 'purple' | 'cyan' | 'green' | 'white'

interface BadgeProps {
  children: React.ReactNode
  variant?: BadgeVariant
  className?: string
  dot?: boolean
}

const variants: Record<BadgeVariant, string> = {
  blue: 'bg-blue-500/10 border-blue-500/25 text-blue-400',
  purple: 'bg-purple-500/10 border-purple-500/25 text-purple-400',
  cyan: 'bg-cyan-500/10 border-cyan-500/25 text-cyan-400',
  green: 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400',
  white: 'bg-white/5 border-white/10 text-slate-300',
}

const dotColors: Record<BadgeVariant, string> = {
  blue: 'bg-blue-400',
  purple: 'bg-purple-400',
  cyan: 'bg-cyan-400',
  green: 'bg-emerald-400',
  white: 'bg-slate-400',
}

export function Badge({
  children,
  variant = 'blue',
  className,
  dot = false,
}: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold',
        'border tracking-wide font-display',
        variants[variant],
        className
      )}
    >
      {dot && (
        <span className="relative flex h-1.5 w-1.5">
          <span
            className={cn(
              'animate-ping absolute inline-flex h-full w-full rounded-full opacity-75',
              dotColors[variant]
            )}
          />
          <span
            className={cn(
              'relative inline-flex rounded-full h-1.5 w-1.5',
              dotColors[variant]
            )}
          />
        </span>
      )}
      {children}
    </span>
  )
}
