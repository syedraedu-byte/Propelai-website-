'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import {
  Cpu, Workflow, MessageSquareCode, Target, BarChart3,
  Shield, Plug, Repeat, Sparkles
} from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { GlowCard } from '@/components/ui/GlowCard'
import { staggerContainer, fadeInUp, fadeInLeft, fadeInRight } from '@/lib/animations'

const features = [
  {
    icon: Cpu,
    title: 'Intelligent AI Agents',
    description:
      'Deploy autonomous agents that handle complex multi-step tasks — from lead qualification to customer support — with human-like reasoning and zero downtime.',
    span: 'lg:col-span-2',
    color: 'blue',
    accent: 'rgba(59,130,246,0.15)',
  },
  {
    icon: Workflow,
    title: 'Visual Workflow Builder',
    description:
      'Connect any tool, trigger any action. Build automation flows visually using Make.com, n8n, or Zapier — then supercharge them with AI decision layers.',
    span: '',
    color: 'purple',
    accent: 'rgba(139,92,246,0.15)',
  },
  {
    icon: MessageSquareCode,
    title: 'Contextual AI Chatbots',
    description:
      'Custom chatbots trained on your business data — answering questions, booking meetings, and qualifying leads 24/7 across web, WhatsApp, and Slack.',
    span: '',
    color: 'cyan',
    accent: 'rgba(6,182,212,0.15)',
  },
  {
    icon: Target,
    title: 'Precision Lead Systems',
    description:
      'AI-driven lead scoring, enrichment, and routing. Connect to your CRM and ensure every hot lead reaches the right rep at exactly the right time.',
    span: '',
    color: 'green',
    accent: 'rgba(16,185,129,0.15)',
  },
  {
    icon: BarChart3,
    title: 'Real-time Analytics',
    description:
      'Every automation ships with live dashboards. Track conversion rates, time saved, and ROI from a single unified operations command center.',
    span: 'lg:col-span-2',
    color: 'blue',
    accent: 'rgba(59,130,246,0.12)',
  },
  {
    icon: Shield,
    title: 'Enterprise-grade Security',
    description:
      'End-to-end encryption, GDPR compliance, SSO, and role-based access control built into every deployment from day one.',
    span: '',
    color: 'purple',
    accent: 'rgba(139,92,246,0.12)',
  },
]

const iconColors = {
  blue: 'text-blue-400 bg-blue-500/10',
  purple: 'text-purple-400 bg-purple-500/10',
  cyan: 'text-cyan-400 bg-cyan-500/10',
  green: 'text-emerald-400 bg-emerald-500/10',
}

export function Features() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Badge variant="purple" className="mb-5">
            ✦ Platform Capabilities
          </Badge>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-800 tracking-tight text-white mb-5 leading-[1.08]">
            Everything you need to
            <br />
            <span className="gradient-text">automate at scale</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto font-body leading-relaxed">
            From AI agents to workflow orchestration, we engineer the full
            automation stack your business needs to operate 10× faster.
          </p>
        </motion.div>

        {/* Bento Grid */}
        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {features.map((feature, i) => {
            const Icon = feature.icon
            const colorClasses = iconColors[feature.color as keyof typeof iconColors]

            return (
              <motion.div
                key={feature.title}
                variants={fadeInUp}
                custom={i}
                className={feature.span}
              >
                <GlowCard
                  className="h-full p-7 group hover:-translate-y-1 transition-transform duration-300"
                  glowColor={feature.accent}
                >
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-2xl ${colorClasses} flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300`}>
                    <Icon size={22} />
                  </div>

                  {/* Content */}
                  <h3 className="text-white font-display font-700 text-xl mb-3 tracking-tight">
                    {feature.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed font-body">
                    {feature.description}
                  </p>

                  {/* Hover arrow */}
                  <div className="mt-5 flex items-center gap-2 text-xs font-semibold opacity-0 group-hover:opacity-100 transition-all duration-300 -translate-x-2 group-hover:translate-x-0">
                    <span className={colorClasses.includes('blue') ? 'text-blue-400' : colorClasses.includes('purple') ? 'text-purple-400' : colorClasses.includes('cyan') ? 'text-cyan-400' : 'text-emerald-400'}>
                      Learn more →
                    </span>
                  </div>
                </GlowCard>
              </motion.div>
            )
          })}
        </motion.div>

        {/* Bottom tech logos marquee */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.7 }}
          className="mt-20 text-center"
        >
          <p className="text-slate-600 text-xs tracking-widest uppercase mb-6 font-display">
            Integrates natively with
          </p>
          <div className="flex items-center justify-center flex-wrap gap-6 opacity-40">
            {[
              'Make.com', 'n8n', 'Zapier', 'HubSpot', 'Salesforce',
              'Slack', 'WhatsApp', 'Notion', 'Airtable', 'OpenAI'
            ].map((tool) => (
              <span key={tool} className="text-slate-300 text-sm font-display font-600 tracking-wide">
                {tool}
              </span>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
