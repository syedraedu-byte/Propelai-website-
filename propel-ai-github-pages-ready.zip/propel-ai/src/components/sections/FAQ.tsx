'use client'

import { useRef, useState } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Plus, Minus } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'

const faqs = [
  {
    q: 'How quickly can you deploy an automation system?',
    a: 'Most systems go live in 72 hours to 7 days depending on complexity. Simple chatbots and single-workflow automations are typically delivered in 48–72 hours. Multi-system integrations (CRM + voice + email) take 5–10 days. We always provide a timeline estimate upfront before starting.',
  },
  {
    q: 'Do I need technical knowledge to use the automations?',
    a: 'Zero. We design every system to be fully managed by your team without any coding knowledge. You get a clean dashboard, training documentation, and a 30-minute walkthrough on handoff. If something breaks, our support team handles it — not you.',
  },
  {
    q: 'Which tools and platforms do you integrate with?',
    a: 'We integrate with virtually any modern SaaS tool — HubSpot, Salesforce, Pipedrive, Notion, Airtable, Slack, WhatsApp Business, Google Workspace, Shopify, Webflow, and 1,000+ more via Make.com, n8n, and Zapier. If you use it, we can automate it.',
  },
  {
    q: 'What makes Propel AI different from hiring a freelancer or using a no-code tool?',
    a: 'Freelancers build fragile systems that break. No-code tools have ceiling limitations. We build production-grade automation architectures — with error handling, fallbacks, monitoring, and AI decision layers — that are designed to scale with your business. We also handle everything end-to-end: strategy, build, deploy, and ongoing optimization.',
  },
  {
    q: 'Can you integrate AI with our existing CRM and sales process?',
    a: 'Yes — this is one of our most common engagements. We connect AI lead scoring, enrichment, and qualification directly into your existing HubSpot, Salesforce, or Pipedrive setup. Your team keeps using the same tools, but now AI is doing the heavy lifting in the background.',
  },
  {
    q: 'What does the onboarding process look like?',
    a: "After your intro call, we run a 1–2 day discovery audit of your current processes, tools, and pain points. We then deliver an Automation Roadmap with prioritized recommendations. Once you approve the scope, we move immediately into the build phase. The entire process from first call to live system typically takes under 2 weeks.",
  },
  {
    q: 'Do you offer ongoing support and optimization?',
    a: "All plans include post-launch support (30–90 days depending on tier). Our Growth and Enterprise clients get proactive monitoring, weekly performance reports, and regular optimization calls where we tune the AI models and workflows based on real usage data. We're invested in your results — not just the build.",
  },
  {
    q: 'How do you handle data security and privacy?',
    a: 'All systems are built with end-to-end encryption, least-privilege API access, and GDPR/DPDP compliance frameworks. We never store sensitive client data on third-party servers without explicit consent. Enterprise clients get a dedicated security review and custom compliance setup.',
  },
]

function FAQItem({ q, a, index }: { q: string; a: string; index: number }) {
  const [open, setOpen] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06, duration: 0.5 }}
      className={`
        border rounded-2xl overflow-hidden transition-all duration-300
        ${open
          ? 'border-blue-500/30 bg-blue-500/[0.03]'
          : 'border-white/[0.07] hover:border-white/[0.13] bg-[rgba(255,255,255,0.02)]'
        }
      `}
    >
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-start justify-between gap-4 p-6 text-left"
        aria-expanded={open}
      >
        <span className="text-white font-display font-600 text-base leading-snug pr-2">
          {q}
        </span>
        <span
          className={`
            w-7 h-7 rounded-lg flex-shrink-0 flex items-center justify-center border transition-all duration-300 mt-0.5
            ${open
              ? 'bg-blue-500/20 border-blue-500/30 text-blue-400'
              : 'bg-white/[0.05] border-white/[0.1] text-slate-400'
            }
          `}
        >
          {open ? <Minus size={14} /> : <Plus size={14} />}
        </span>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
          >
            <div className="px-6 pb-6">
              <div className="h-px bg-white/[0.06] mb-4" />
              <p className="text-slate-400 text-sm leading-relaxed font-body">{a}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  )
}

export function FAQ() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      <div className="relative max-w-4xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <Badge variant="white" className="mb-5">✦ FAQ</Badge>
          <h2 className="text-4xl sm:text-5xl font-display font-800 tracking-tight text-white mb-4 leading-[1.08]">
            Questions, <span className="gradient-text">answered</span>
          </h2>
          <p className="text-slate-400 text-lg font-body max-w-xl mx-auto">
            Everything you need to know before working with us.
          </p>
        </motion.div>

        {/* Accordion */}
        <div className="flex flex-col gap-3">
          {faqs.map((faq, i) => (
            <FAQItem key={i} q={faq.q} a={faq.a} index={i} />
          ))}
        </div>

        {/* Bottom prompt */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="mt-12 text-center p-8 rounded-2xl glass border border-white/[0.07]"
        >
          <p className="text-slate-300 font-body mb-2">
            Still have questions?
          </p>
          <p className="text-slate-500 text-sm font-body mb-5">
            We&apos;re happy to walk you through everything on a free 20-minute call.
          </p>
          <a
            href="/contact"
            className="inline-flex items-center gap-2 text-sm font-semibold text-blue-400 hover:text-blue-300 transition-colors duration-200"
          >
            Book a free discovery call →
          </a>
        </motion.div>
      </div>
    </section>
  )
}
