'use client'

import { useRef } from 'react'
import Link from 'next/link'
import { motion, useScroll, useTransform } from 'framer-motion'
import {
  ArrowRight, Bot, TrendingUp, Zap, Clock, CheckCircle2,
  Play, ChevronDown
} from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { GridBackground, GlowOrbs } from '@/components/effects/GridBackground'
import { staggerContainer, fadeInUp } from '@/lib/animations'

/* ── Floating metric cards ──────────────────────────────────── */
const metrics = [
  {
    icon: TrendingUp,
    value: '10M+',
    label: 'Revenue Automated',
    color: 'blue',
    delay: 0,
    position: 'top-[18%] -left-2 lg:left-6',
  },
  {
    icon: Bot,
    value: '500+',
    label: 'Workflows Deployed',
    color: 'purple',
    delay: 0.2,
    position: 'top-[62%] -left-2 lg:left-12',
  },
  {
    icon: Zap,
    value: '98%',
    label: 'Client Satisfaction',
    color: 'cyan',
    delay: 0.4,
    position: 'top-[24%] -right-2 lg:right-6',
  },
  {
    icon: Clock,
    value: '72hrs',
    label: 'Average Deploy Time',
    color: 'green',
    delay: 0.6,
    position: 'top-[65%] -right-2 lg:right-10',
  },
]

const colorMap: Record<string, string> = {
  blue: 'from-blue-500/10 to-blue-500/5 border-blue-500/20 text-blue-400',
  purple: 'from-purple-500/10 to-purple-500/5 border-purple-500/20 text-purple-400',
  cyan: 'from-cyan-500/10 to-cyan-500/5 border-cyan-500/20 text-cyan-400',
  green: 'from-emerald-500/10 to-emerald-500/5 border-emerald-500/20 text-emerald-400',
}

/* ── Words to animate in headline ──────────────────────────── */
const headline1 = ['Automate', 'Growth.']
const headline2 = ['Eliminate', 'Repetition.']

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end start'],
  })
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '30%'])
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0])

  return (
    <section
      ref={containerRef}
      className="relative min-h-[100svh] flex flex-col items-center justify-center overflow-hidden pt-24 pb-16"
    >
      {/* ── Background layers ─────────────────────────────────── */}
      <GridBackground variant="dots" intensity="subtle" />
      <GlowOrbs />

      {/* Hero gradient radial */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 90% 60% at 50% -5%, rgba(59,130,246,0.12) 0%, transparent 65%)',
        }}
      />

      {/* ── Parallax content wrapper ─────────────────────────── */}
      <motion.div
        style={{ y, opacity }}
        className="relative z-10 w-full max-w-7xl mx-auto px-6"
      >
        {/* ── Badge ──────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="flex justify-center mb-8"
        >
          <Badge variant="blue" dot className="text-[0.7rem] tracking-widest uppercase font-display">
            ✦ AI Automation Agency · Est. 2024
          </Badge>
        </motion.div>

        {/* ── Headline ───────────────────────────────────────── */}
        <div className="text-center mb-8">
          {/* Line 1 */}
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="flex flex-wrap justify-center gap-x-5 mb-1 overflow-hidden"
          >
            {headline1.map((word, i) => (
              <div key={i} className="overflow-hidden">
                <motion.span
                  variants={{
                    hidden: { y: '110%', opacity: 0 },
                    visible: {
                      y: '0%',
                      opacity: 1,
                      transition: {
                        duration: 0.7,
                        ease: [0.16, 1, 0.3, 1],
                        delay: i * 0.12,
                      },
                    },
                  }}
                  className="block text-[3.2rem] sm:text-[4.5rem] lg:text-[5.5rem] xl:text-[6.5rem] font-display font-800 leading-[1.02] tracking-[-0.03em] text-white"
                >
                  {word === 'Growth.' ? (
                    <span className="gradient-text-full">{word}</span>
                  ) : (
                    word
                  )}
                </motion.span>
              </div>
            ))}
          </motion.div>

          {/* Line 2 */}
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="flex flex-wrap justify-center gap-x-5 overflow-hidden"
          >
            {headline2.map((word, i) => (
              <div key={i} className="overflow-hidden">
                <motion.span
                  variants={{
                    hidden: { y: '110%', opacity: 0 },
                    visible: {
                      y: '0%',
                      opacity: 1,
                      transition: {
                        duration: 0.7,
                        ease: [0.16, 1, 0.3, 1],
                        delay: i * 0.12 + 0.25,
                      },
                    },
                  }}
                  className="block text-[3.2rem] sm:text-[4.5rem] lg:text-[5.5rem] xl:text-[6.5rem] font-display font-800 leading-[1.02] tracking-[-0.03em] text-slate-300"
                >
                  {word}
                </motion.span>
              </div>
            ))}
          </motion.div>
        </div>

        {/* ── Subtext ────────────────────────────────────────── */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
          className="text-slate-400 text-lg md:text-xl text-center max-w-2xl mx-auto leading-relaxed mb-10 font-body"
        >
          We build intelligent automation systems that scale your operations,
          convert more leads, and free your team from repetitive work — using
          cutting-edge AI agents, voice bots, and workflow orchestration.
        </motion.p>

        {/* ── CTAs ───────────────────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.75 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-14"
        >
          <Link href="/contact">
            <Button
              variant="glow"
              size="lg"
              icon={<ArrowRight size={18} />}
              iconPosition="right"
              className="font-display font-600 min-w-[200px]"
            >
              Start Automating
            </Button>
          </Link>
          <Link href="/services">
            <Button
              variant="secondary"
              size="lg"
              icon={<Play size={15} className="fill-current" />}
              iconPosition="left"
              className="font-display font-600 min-w-[200px]"
            >
              See Our Work
            </Button>
          </Link>
        </motion.div>

        {/* ── Social proof strip ─────────────────────────────── */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-6"
        >
          {/* Avatars */}
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              {['🧑‍💼', '👩‍💻', '🧑‍🔬', '👩‍💼', '🧑‍🎨'].map((emoji, i) => (
                <div
                  key={i}
                  className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-600/50 to-purple-600/50 border-2 border-[#050508] flex items-center justify-center text-sm"
                >
                  {emoji}
                </div>
              ))}
            </div>
            <div className="text-sm text-slate-400 font-body">
              <span className="text-white font-semibold">200+</span> businesses automated
            </div>
          </div>

          <div className="hidden sm:block w-px h-5 bg-white/10" />

          {/* Checkmarks */}
          <div className="flex items-center gap-4">
            {['No-code setup', 'Scales instantly', '24/7 support'].map((item) => (
              <div key={item} className="flex items-center gap-1.5 text-sm text-slate-400">
                <CheckCircle2 size={14} className="text-blue-400 shrink-0" />
                {item}
              </div>
            ))}
          </div>
        </motion.div>
      </motion.div>

      {/* ── Floating metric cards ─────────────────────────────── */}
      {metrics.map(({ icon: Icon, value, label, color, delay, position }) => (
        <motion.div
          key={label}
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 + delay, ease: [0.34, 1.56, 0.64, 1] }}
          className={`absolute ${position} animate-float hidden lg:block z-20`}
          style={{ animationDelay: `${delay * 0.5}s` }}
        >
          <div
            className={`
              flex items-center gap-3 px-4 py-3 rounded-2xl
              bg-gradient-to-br ${colorMap[color]}
              border backdrop-blur-md
              shadow-[0_8px_32px_rgba(0,0,0,0.4)]
            `}
          >
            <div className="w-9 h-9 rounded-xl bg-current/10 flex items-center justify-center">
              <Icon size={18} className="opacity-90" />
            </div>
            <div>
              <div className="text-white font-display font-700 text-lg leading-none">{value}</div>
              <div className="text-xs opacity-70 mt-0.5 font-body whitespace-nowrap">{label}</div>
            </div>
          </div>
        </motion.div>
      ))}

      {/* ── Scroll indicator ─────────────────────────────────── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.8, duration: 0.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-600"
      >
        <span className="text-xs tracking-widest uppercase font-body">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown size={18} />
        </motion.div>
      </motion.div>

      {/* ── Bottom gradient fade ──────────────────────────────── */}
      <div
        className="absolute bottom-0 left-0 right-0 h-40 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, transparent, #050508)',
        }}
      />
    </section>
  )
}
