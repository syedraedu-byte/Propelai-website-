'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, useInView, AnimatePresence } from 'framer-motion'
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'

const testimonials = [
  {
    quote:
      'Propel AI transformed our entire lead qualification process. We went from spending 3 hours/day on manual follow-ups to having everything handled by their AI agent — while our conversion rate tripled.',
    name: 'Arjun Mehta',
    role: 'Head of Sales',
    company: 'TechScale India',
    avatar: 'AM',
    avatarGradient: 'from-blue-500 to-purple-600',
    rating: 5,
    metric: '3× conversion rate',
  },
  {
    quote:
      'The AI voice agent they deployed for our real estate team now handles 200+ inquiry calls per week. It qualifies leads, books site visits, and syncs to our CRM — all without a single human touching it.',
    name: 'Priya Sharma',
    role: 'Operations Director',
    company: 'Myron Realty',
    avatar: 'PS',
    avatarGradient: 'from-purple-500 to-pink-600',
    rating: 5,
    metric: '200+ calls automated/week',
  },
  {
    quote:
      'Within 72 hours of kickoff, we had a fully functional customer support chatbot live on our platform. It now handles 78% of inbound queries autonomously. ROI in the first week was insane.',
    name: 'David Chen',
    role: 'CTO',
    company: 'GrowthOS SaaS',
    avatar: 'DC',
    avatarGradient: 'from-cyan-500 to-blue-600',
    rating: 5,
    metric: '78% query resolution',
  },
  {
    quote:
      "Their CRM automation rebuilt our entire pipeline. What used to require a team of 4 people now runs on autopilot. I can't imagine running our coaching institute without it.",
    name: 'Neha Agarwal',
    role: 'Founder',
    company: 'Apex Coaching',
    avatar: 'NA',
    avatarGradient: 'from-emerald-500 to-cyan-600',
    rating: 5,
    metric: '4-person team → automation',
  },
  {
    quote:
      "We deployed Propel AI's email automation for our SaaS onboarding. Personalized sequences, behavior-triggered nudges, and churn prediction — open rates jumped 52% in 30 days.",
    name: 'Marcus Williams',
    role: 'VP Marketing',
    company: 'Inflect Analytics',
    avatar: 'MW',
    avatarGradient: 'from-amber-500 to-orange-600',
    rating: 5,
    metric: '+52% email open rates',
  },
  {
    quote:
      'The quality of systems they build is enterprise-level — the speed is startup speed. No other agency delivers both. This team genuinely understands AI automation at a technical depth.',
    name: 'Aisha Patel',
    role: 'CEO',
    company: 'FinFlow Ventures',
    avatar: 'AP',
    avatarGradient: 'from-violet-500 to-purple-700',
    rating: 5,
    metric: 'Enterprise quality, startup speed',
  },
]

export function Testimonials() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  const [activeIndex, setActiveIndex] = useState(0)
  const [direction, setDirection] = useState<1 | -1>(1)

  const prev = () => {
    setDirection(-1)
    setActiveIndex((i) => (i - 1 + testimonials.length) % testimonials.length)
  }

  const next = () => {
    setDirection(1)
    setActiveIndex((i) => (i + 1) % testimonials.length)
  }

  // Auto-advance
  useEffect(() => {
    const timer = setInterval(next, 5500)
    return () => clearInterval(timer)
  }, [])

  const t = testimonials[activeIndex]

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Ambient */}
      <div
        className="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 w-[800px] h-[500px] opacity-[0.04] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse, #3b82f6, transparent)',
          filter: 'blur(100px)',
        }}
      />

      <div className="relative max-w-5xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Badge variant="blue" className="mb-5">
            ✦ Client Stories
          </Badge>
          <h2 className="text-4xl sm:text-5xl font-display font-800 tracking-tight text-white mb-4 leading-[1.08]">
            Trusted by <span className="gradient-text">200+ businesses</span>
          </h2>
          <p className="text-slate-400 text-lg font-body">
            From startups to enterprise ops teams — here&apos;s what our clients say.
          </p>
        </motion.div>

        {/* Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.2 }}
        >
          {/* Main card */}
          <div className="relative">
            <AnimatePresence mode="wait" custom={direction}>
              <motion.div
                key={activeIndex}
                custom={direction}
                initial={{ opacity: 0, x: direction * 60 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: direction * -60 }}
                transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
                className="relative rounded-3xl p-8 md:p-12 glass border border-white/[0.08] shadow-[0_4px_40px_rgba(0,0,0,0.5)]"
              >
                {/* Quote icon */}
                <div className="absolute top-8 right-8 text-blue-500/20">
                  <Quote size={64} />
                </div>

                {/* Stars */}
                <div className="flex gap-1 mb-6">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={16} className="text-amber-400 fill-amber-400" />
                  ))}
                </div>

                {/* Metric badge */}
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold mb-5 font-display">
                  → {t.metric}
                </div>

                {/* Quote text */}
                <blockquote className="text-slate-200 text-lg md:text-xl leading-relaxed font-body mb-8 max-w-3xl">
                  &ldquo;{t.quote}&rdquo;
                </blockquote>

                {/* Author */}
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${t.avatarGradient} flex items-center justify-center text-white font-display font-700 text-sm flex-shrink-0`}>
                    {t.avatar}
                  </div>
                  <div>
                    <div className="text-white font-display font-700 text-base">{t.name}</div>
                    <div className="text-slate-400 text-sm font-body">
                      {t.role} · {t.company}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-between mt-8">
            {/* Dot indicators */}
            <div className="flex items-center gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setDirection(i > activeIndex ? 1 : -1)
                    setActiveIndex(i)
                  }}
                  className={`
                    transition-all duration-300 rounded-full
                    ${i === activeIndex
                      ? 'w-6 h-2 bg-blue-500'
                      : 'w-2 h-2 bg-white/20 hover:bg-white/40'
                    }
                  `}
                  aria-label={`Go to testimonial ${i + 1}`}
                />
              ))}
            </div>

            {/* Arrow buttons */}
            <div className="flex items-center gap-2">
              <button
                onClick={prev}
                className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/[0.08] flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/[0.1] transition-all duration-200"
                aria-label="Previous testimonial"
              >
                <ChevronLeft size={18} />
              </button>
              <button
                onClick={next}
                className="w-10 h-10 rounded-xl bg-white/[0.05] border border-white/[0.08] flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/[0.1] transition-all duration-200"
                aria-label="Next testimonial"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
