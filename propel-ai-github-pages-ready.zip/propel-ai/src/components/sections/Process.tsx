'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { Search, Cpu, Rocket, BarChart3 } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { staggerContainer, fadeInUp } from '@/lib/animations'

const steps = [
  {
    number: '01',
    icon: Search,
    title: 'Discovery & Audit',
    description:
      'We audit your current workflows, identify the highest-ROI automation opportunities, and map your tech stack. You leave with a clear picture of what to automate first.',
    duration: '1–2 Days',
    deliverable: 'Automation Roadmap',
    color: 'blue',
  },
  {
    number: '02',
    icon: Cpu,
    title: 'Architecture & Design',
    description:
      'We design the full system architecture — data flows, AI decision logic, integration points, and fallback mechanisms — before a single line of code is written.',
    duration: '2–3 Days',
    deliverable: 'Technical Blueprint',
    color: 'purple',
  },
  {
    number: '03',
    icon: Rocket,
    title: 'Build & Deploy',
    description:
      'We build, test, and deploy your automation system — from AI agent setup to CRM integration to voice flows — fully end-to-end in an average of 72 hours.',
    duration: '3–7 Days',
    deliverable: 'Live System',
    color: 'cyan',
  },
  {
    number: '04',
    icon: BarChart3,
    title: 'Monitor & Scale',
    description:
      'Post-launch, we monitor performance, tune AI models, optimize conversion rates, and help you scale the system as your business grows.',
    duration: 'Ongoing',
    deliverable: 'Growth Reporting',
    color: 'green',
  },
]

const colorMap = {
  blue: {
    number: 'text-blue-500',
    icon: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
    badge: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    connector: 'bg-gradient-to-b from-blue-500/50 to-purple-500/50',
    glow: 'hover:border-blue-500/30 hover:shadow-[0_0_30px_rgba(59,130,246,0.08)]',
  },
  purple: {
    number: 'text-purple-500',
    icon: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
    badge: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    connector: 'bg-gradient-to-b from-purple-500/50 to-cyan-500/50',
    glow: 'hover:border-purple-500/30 hover:shadow-[0_0_30px_rgba(139,92,246,0.08)]',
  },
  cyan: {
    number: 'text-cyan-500',
    icon: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
    badge: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
    connector: 'bg-gradient-to-b from-cyan-500/50 to-emerald-500/50',
    glow: 'hover:border-cyan-500/30 hover:shadow-[0_0_30px_rgba(6,182,212,0.08)]',
  },
  green: {
    number: 'text-emerald-500',
    icon: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    connector: 'bg-transparent',
    glow: 'hover:border-emerald-500/30 hover:shadow-[0_0_30px_rgba(16,185,129,0.08)]',
  },
}

export function Process() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Right-side ambient glow */}
      <div
        className="absolute right-0 top-1/2 -translate-y-1/2 w-[500px] h-[600px] opacity-[0.05] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse, #06b6d4, transparent)',
          filter: 'blur(80px)',
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Badge variant="white" className="mb-5">
            ✦ Our Process
          </Badge>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-800 tracking-tight text-white mb-5 leading-[1.08]">
            From idea to automation
            <br />
            <span className="gradient-text">in 72 hours</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto font-body leading-relaxed">
            Our proven 4-step framework delivers production-grade automation systems
            faster than any traditional agency — with zero compromises on quality.
          </p>
        </motion.div>

        {/* Steps — desktop horizontal, mobile vertical */}
        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-1 lg:grid-cols-4 gap-6 relative"
        >
          {/* Connector line (desktop) */}
          <div
            className="absolute top-[3.5rem] left-[16.5%] right-[16.5%] h-px hidden lg:block"
            style={{
              background:
                'linear-gradient(90deg, rgba(59,130,246,0.5), rgba(139,92,246,0.5), rgba(6,182,212,0.5), rgba(16,185,129,0.5))',
            }}
          />

          {steps.map((step, i) => {
            const Icon = step.icon
            const colors = colorMap[step.color as keyof typeof colorMap]

            return (
              <motion.div
                key={step.number}
                variants={fadeInUp}
                custom={i}
                className="relative"
              >
                <div
                  className={`
                    relative p-6 rounded-2xl h-full
                    bg-[rgba(255,255,255,0.025)]
                    border border-white/[0.07]
                    ${colors.glow}
                    transition-all duration-300
                    group
                  `}
                >
                  {/* Step number + icon */}
                  <div className="flex items-center gap-3 mb-5">
                    <div
                      className={`
                        relative w-12 h-12 rounded-2xl border flex items-center justify-center flex-shrink-0
                        ${colors.icon}
                        group-hover:scale-110 transition-transform duration-300
                      `}
                    >
                      <Icon size={20} />
                      {/* Connector dot (desktop) */}
                      <div
                        className={`
                          absolute -top-[1.95rem] left-1/2 -translate-x-1/2
                          w-2.5 h-2.5 rounded-full border-2 border-[#050508]
                          hidden lg:block
                          ${colors.icon}
                        `}
                        style={{ background: 'currentColor' }}
                      />
                    </div>
                    <span className={`text-3xl font-display font-800 ${colors.number} opacity-30`}>
                      {step.number}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-white font-display font-700 text-lg mb-3 tracking-tight">
                    {step.title}
                  </h3>

                  {/* Description */}
                  <p className="text-slate-400 text-sm leading-relaxed font-body mb-5">
                    {step.description}
                  </p>

                  {/* Meta */}
                  <div className="flex items-center justify-between pt-4 border-t border-white/[0.06]">
                    <span className={`text-xs font-semibold px-2.5 py-1 rounded-lg border ${colors.badge} font-display`}>
                      {step.duration}
                    </span>
                    <span className="text-xs text-slate-500 font-body">
                      → {step.deliverable}
                    </span>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
