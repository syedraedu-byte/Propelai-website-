'use client'

import { useRef, useState } from 'react'
import Link from 'next/link'
import { motion, useInView } from 'framer-motion'
import { CheckCircle2, Zap, Building2, Rocket, ArrowRight } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { staggerContainer, fadeInUp } from '@/lib/animations'
import { cn } from '@/lib/utils'

const plans = [
  {
    icon: Rocket,
    name: 'Starter',
    tagline: 'For early-stage businesses',
    price: { monthly: 799, annual: 639 },
    description:
      'Perfect for SMBs wanting to automate their first critical workflow and start saving hours immediately.',
    features: [
      '1 custom automation workflow',
      'AI chatbot (up to 1,000 conversations/mo)',
      'CRM integration (HubSpot or Sheets)',
      'Email automation setup',
      '30-day post-launch support',
      'Analytics dashboard',
    ],
    cta: 'Get Started',
    color: 'default',
    popular: false,
  },
  {
    icon: Zap,
    name: 'Growth',
    tagline: 'Most popular for scaling teams',
    price: { monthly: 1999, annual: 1599 },
    description:
      'For fast-growing companies that need a full automation stack — AI agents, lead systems, and CRM syncing.',
    features: [
      'Up to 5 automation workflows',
      'AI chatbot + voice agent',
      'Lead generation system',
      'Full CRM automation',
      'AI email sequences',
      '90-day priority support',
      'Custom analytics & reporting',
      'Weekly optimization calls',
    ],
    cta: 'Start Growing',
    color: 'blue',
    popular: true,
  },
  {
    icon: Building2,
    name: 'Enterprise',
    tagline: 'For ops-heavy organizations',
    price: { monthly: null, annual: null },
    description:
      'Custom-scoped engagements for enterprises that need dedicated automation architects and full-stack AI deployment.',
    features: [
      'Unlimited workflows',
      'Dedicated AI architect',
      'Custom AI agent development',
      'On-premise or cloud deploy',
      'SLA-backed uptime guarantees',
      '24/7 white-glove support',
      'Security & compliance review',
      'Quarterly strategy sessions',
    ],
    cta: 'Book a Call',
    color: 'purple',
    popular: false,
  },
]

export function Pricing() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  const [annual, setAnnual] = useState(false)

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] opacity-[0.04] pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, #8b5cf6, transparent)', filter: 'blur(100px)' }}
      />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-14"
        >
          <Badge variant="purple" className="mb-5">✦ Transparent Pricing</Badge>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-800 tracking-tight text-white mb-5 leading-[1.08]">
            Simple pricing,
            <br />
            <span className="gradient-text">extraordinary results</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-xl mx-auto font-body leading-relaxed mb-8">
            No hidden fees. No lock-in. Pay for what you need, scale when you&apos;re ready.
          </p>

          {/* Toggle */}
          <div className="inline-flex items-center gap-3 p-1 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
            <button
              onClick={() => setAnnual(false)}
              className={cn(
                'px-5 py-2 rounded-xl text-sm font-display font-600 transition-all duration-200',
                !annual ? 'bg-white/[0.1] text-white shadow-sm' : 'text-slate-400 hover:text-white'
              )}
            >Monthly</button>
            <button
              onClick={() => setAnnual(true)}
              className={cn(
                'px-5 py-2 rounded-xl text-sm font-display font-600 transition-all duration-200 flex items-center gap-2',
                annual ? 'bg-white/[0.1] text-white shadow-sm' : 'text-slate-400 hover:text-white'
              )}
            >
              Annual
              <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/25 px-2 py-0.5 rounded-lg">Save 20%</span>
            </button>
          </div>
        </motion.div>

        {/* Cards */}
        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {plans.map((plan) => {
            const Icon = plan.icon
            const isPopular = plan.popular
            const price = annual ? plan.price.annual : plan.price.monthly

            return (
              <motion.div key={plan.name} variants={fadeInUp} className="relative">
                {/* Popular badge */}
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
                    <span className="px-4 py-1.5 rounded-full text-xs font-display font-700 bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-glow-blue whitespace-nowrap">
                      ✦ Most Popular
                    </span>
                  </div>
                )}

                <div
                  className={cn(
                    'relative rounded-3xl p-7 h-full flex flex-col',
                    'bg-[rgba(255,255,255,0.025)] border transition-all duration-300',
                    'hover:-translate-y-1',
                    isPopular
                      ? 'border-blue-500/40 shadow-[0_0_50px_rgba(59,130,246,0.15)]'
                      : plan.color === 'purple'
                      ? 'border-purple-500/20 hover:border-purple-500/35'
                      : 'border-white/[0.07] hover:border-white/[0.15]'
                  )}
                >
                  {/* Gradient top accent */}
                  {isPopular && (
                    <div className="absolute top-0 left-6 right-6 h-px bg-gradient-to-r from-transparent via-blue-500/70 to-transparent" />
                  )}

                  {/* Icon + Name */}
                  <div className="flex items-center gap-3 mb-5">
                    <div className={cn(
                      'w-10 h-10 rounded-xl flex items-center justify-center border',
                      isPopular
                        ? 'text-blue-400 bg-blue-500/10 border-blue-500/25'
                        : plan.color === 'purple'
                        ? 'text-purple-400 bg-purple-500/10 border-purple-500/25'
                        : 'text-slate-300 bg-white/[0.05] border-white/[0.1]'
                    )}>
                      <Icon size={18} />
                    </div>
                    <div>
                      <div className="text-white font-display font-700 text-base">{plan.name}</div>
                      <div className="text-slate-500 text-xs font-body">{plan.tagline}</div>
                    </div>
                  </div>

                  {/* Price */}
                  <div className="mb-5">
                    {price ? (
                      <div className="flex items-end gap-1.5">
                        <span className="text-slate-400 text-lg font-body">$</span>
                        <span className="text-5xl font-display font-800 text-white leading-none">
                          {price.toLocaleString()}
                        </span>
                        <span className="text-slate-400 text-sm font-body pb-1">/mo</span>
                      </div>
                    ) : (
                      <div className="text-4xl font-display font-800 text-white">Custom</div>
                    )}
                  </div>

                  {/* Description */}
                  <p className="text-slate-400 text-sm leading-relaxed font-body mb-6 pb-6 border-b border-white/[0.06]">
                    {plan.description}
                  </p>

                  {/* Features */}
                  <ul className="flex flex-col gap-3 mb-8 flex-1">
                    {plan.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-sm text-slate-300 font-body">
                        <CheckCircle2
                          size={15}
                          className={cn(
                            'mt-0.5 flex-shrink-0',
                            isPopular ? 'text-blue-400' : plan.color === 'purple' ? 'text-purple-400' : 'text-slate-400'
                          )}
                        />
                        {f}
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <Link href="/contact">
                    <Button
                      variant={isPopular ? 'primary' : plan.color === 'purple' ? 'outline' : 'secondary'}
                      size="lg"
                      icon={<ArrowRight size={16} />}
                      className="w-full justify-center font-display"
                    >
                      {plan.cta}
                    </Button>
                  </Link>
                </div>
              </motion.div>
            )
          })}
        </motion.div>

        {/* Footer note */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="text-center text-slate-600 text-sm mt-10 font-body"
        >
          All plans include a free discovery call. No contracts, cancel anytime.
        </motion.p>
      </div>
    </section>
  )
}
