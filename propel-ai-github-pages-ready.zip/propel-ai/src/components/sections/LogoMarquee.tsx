'use client'

import { motion } from 'framer-motion'

const companies = [
  'TechScale India', 'Myron Group', 'Apex Coaching', 'GrowthOS',
  'FinFlow Ventures', 'Inflect Analytics', 'VentureBase', 'SkyOps',
  'LeadForge', 'Nexacore', 'Orbit Labs', 'Pulse Media',
  // Duplicate for seamless loop
  'TechScale India', 'Myron Group', 'Apex Coaching', 'GrowthOS',
  'FinFlow Ventures', 'Inflect Analytics', 'VentureBase', 'SkyOps',
  'LeadForge', 'Nexacore', 'Orbit Labs', 'Pulse Media',
]

export function LogoMarquee() {
  return (
    <section className="relative py-14 overflow-hidden">
      {/* Top border */}
      <div className="absolute top-0 left-0 right-0 h-px bg-white/[0.05]" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-white/[0.05]" />

      {/* Fade edges */}
      <div className="absolute left-0 top-0 bottom-0 w-40 z-10 pointer-events-none"
        style={{ background: 'linear-gradient(to right, #050508, transparent)' }} />
      <div className="absolute right-0 top-0 bottom-0 w-40 z-10 pointer-events-none"
        style={{ background: 'linear-gradient(to left, #050508, transparent)' }} />

      {/* Label */}
      <div className="text-center mb-8">
        <p className="text-slate-600 text-xs tracking-widest uppercase font-display">
          Trusted by innovative companies
        </p>
      </div>

      {/* Marquee track */}
      <div className="flex overflow-hidden">
        <motion.div
          animate={{ x: ['0%', '-50%'] }}
          transition={{ duration: 35, ease: 'linear', repeat: Infinity }}
          className="flex items-center gap-14 whitespace-nowrap"
        >
          {companies.map((name, i) => (
            <span
              key={`${name}-${i}`}
              className="text-slate-500 hover:text-slate-300 font-display font-600 text-sm tracking-wide transition-colors duration-300 cursor-default"
            >
              {name}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
