'use client'

import { useRef } from 'react'
import Link from 'next/link'
import { motion, useInView } from 'framer-motion'
import {
  Bot, GitBranch, Users, Mic2, Mail, Database, TrendingUp,
  CheckCircle, ArrowRight
} from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { GlowCard } from '@/components/ui/GlowCard'
import { staggerContainer, fadeInUp } from '@/lib/animations'

export const services = [
  {
    icon: Bot,
    title: 'AI Automation Systems',
    tagline: 'Automate Any Workflow',
    description:
      'End-to-end intelligent automation that handles intake, processing, decision-making, and output — replacing entire manual processes with AI-powered pipelines.',
    outcomes: ['80% reduction in manual tasks', 'Zero human errors in data processing', '24/7 uptime'],
    color: 'blue',
    gradient: 'from-blue-500/15 to-blue-600/5',
    border: 'hover:border-blue-500/30',
    glowColor: 'rgba(59,130,246,0.15)',
    href: '/services',
  },
  {
    icon: GitBranch,
    title: 'Workflow Optimization',
    tagline: 'Engineer Your Ops Stack',
    description:
      'Map, re-engineer, and automate your business processes using Make.com, n8n, or Zapier. We turn chaotic operations into elegant, reliable systems.',
    outcomes: ['3× faster process execution', 'Full cross-tool integration', 'Live monitoring dashboards'],
    color: 'purple',
    gradient: 'from-purple-500/15 to-purple-600/5',
    border: 'hover:border-purple-500/30',
    glowColor: 'rgba(139,92,246,0.15)',
    href: '/services',
  },
  {
    icon: Users,
    title: 'AI Chatbots & Agents',
    tagline: 'Deploy 24/7 AI Support',
    description:
      'Intelligent conversational agents trained on your content — for customer support, lead qualification, onboarding, FAQs, and appointment booking.',
    outcomes: ['Handle 1000s of conversations daily', '70% reduction in support tickets', 'Multi-channel deployment'],
    color: 'cyan',
    gradient: 'from-cyan-500/15 to-cyan-600/5',
    border: 'hover:border-cyan-500/30',
    glowColor: 'rgba(6,182,212,0.15)',
    href: '/services',
  },
  {
    icon: Mic2,
    title: 'AI Voice Agents',
    tagline: 'Humanlike Voice AI',
    description:
      'Deploy AI-powered voice agents for inbound/outbound calls. Handle sales queries, qualify leads, and book appointments — all with natural-sounding AI.',
    outcomes: ['Handle 100s of calls simultaneously', 'Lead qualification at scale', 'Instant CRM sync'],
    color: 'violet',
    gradient: 'from-violet-500/15 to-violet-600/5',
    border: 'hover:border-violet-500/30',
    glowColor: 'rgba(124,58,237,0.15)',
    href: '/services',
  },
  {
    icon: TrendingUp,
    title: 'Lead Generation Systems',
    tagline: 'Fill Your Pipeline with AI',
    description:
      'Automated lead sourcing, scoring, enrichment, and CRM routing. Build a reliable inbound engine that delivers qualified prospects on autopilot.',
    outcomes: ['5× increase in qualified leads', 'Auto-enriched prospect data', 'CRM-native integration'],
    color: 'green',
    gradient: 'from-emerald-500/15 to-emerald-600/5',
    border: 'hover:border-emerald-500/30',
    glowColor: 'rgba(16,185,129,0.15)',
    href: '/services',
  },
  {
    icon: Mail,
    title: 'AI Email Automation',
    tagline: 'Personalize at Scale',
    description:
      'AI-generated, behavior-triggered email sequences that respond to user actions, personalize content, and nurture leads through your funnel automatically.',
    outcomes: ['45% higher open rates', 'Personalized at 1:1 scale', 'Behavior-triggered flows'],
    color: 'amber',
    gradient: 'from-amber-500/15 to-amber-600/5',
    border: 'hover:border-amber-500/30',
    glowColor: 'rgba(245,158,11,0.12)',
    href: '/services',
  },
  {
    icon: Database,
    title: 'CRM Automation',
    tagline: 'Sync. Score. Convert.',
    description:
      'Connect HubSpot, Salesforce, or Pipedrive to your entire operation. Automate deal stages, contact scoring, follow-up sequences, and team notifications.',
    outcomes: ['100% data entry eliminated', 'Automated deal progression', 'Real-time rep alerts'],
    color: 'rose',
    gradient: 'from-rose-500/15 to-rose-600/5',
    border: 'hover:border-rose-500/30',
    glowColor: 'rgba(244,63,94,0.12)',
    href: '/services',
  },
]

const iconColorMap: Record<string, string> = {
  blue: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  cyan: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  violet: 'text-violet-400 bg-violet-500/10 border-violet-500/20',
  green: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  rose: 'text-rose-400 bg-rose-500/10 border-rose-500/20',
}

export function Services() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      {/* Ambient background glow */}
      <div
        className="absolute left-0 top-1/2 -translate-y-1/2 w-[500px] h-[500px] opacity-[0.06] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse, #8b5cf6, transparent)',
          filter: 'blur(80px)',
        }}
      />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Badge variant="cyan" className="mb-5">
            ✦ What We Build
          </Badge>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-800 tracking-tight text-white mb-5 leading-[1.08]">
            Services engineered for
            <br />
            <span className="gradient-text">real business results</span>
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto font-body leading-relaxed">
            Each service is a fully customized system built for your industry, stack, and growth stage — not a one-size-fits-all template.
          </p>
        </motion.div>

        {/* Services grid */}
        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          {services.slice(0, 6).map((service) => {
            const Icon = service.icon
            const iconClasses = iconColorMap[service.color] || 'text-blue-400 bg-blue-500/10 border-blue-500/20'

            return (
              <motion.div key={service.title} variants={fadeInUp}>
                <GlowCard
                  className={`h-full p-7 group cursor-pointer border ${service.border} transition-all duration-300 hover:-translate-y-1`}
                  glowColor={service.glowColor}
                >
                  {/* Top section */}
                  <div className="flex items-start gap-4 mb-5">
                    <div className={`w-12 h-12 rounded-2xl border flex-shrink-0 flex items-center justify-center ${iconClasses} group-hover:scale-110 transition-transform duration-300`}>
                      <Icon size={20} />
                    </div>
                    <div>
                      <div className="text-xs font-semibold tracking-widest uppercase text-slate-500 font-display mb-1">
                        {service.tagline}
                      </div>
                      <h3 className="text-white font-display font-700 text-lg tracking-tight leading-snug">
                        {service.title}
                      </h3>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-slate-400 text-sm leading-relaxed font-body mb-5">
                    {service.description}
                  </p>

                  {/* Outcomes */}
                  <ul className="flex flex-col gap-2 mb-6">
                    {service.outcomes.map((outcome) => (
                      <li key={outcome} className="flex items-center gap-2 text-xs text-slate-300 font-body">
                        <CheckCircle size={13} className="text-blue-400 flex-shrink-0" />
                        {outcome}
                      </li>
                    ))}
                  </ul>

                  {/* CTA */}
                  <Link
                    href={service.href}
                    className="inline-flex items-center gap-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors duration-200 group/link"
                  >
                    Learn more
                    <ArrowRight
                      size={13}
                      className="translate-x-0 group-hover/link:translate-x-1 transition-transform duration-200"
                    />
                  </Link>
                </GlowCard>
              </motion.div>
            )
          })}
        </motion.div>

        {/* View all CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.5 }}
          className="text-center mt-12"
        >
          <Link
            href="/services"
            className="inline-flex items-center gap-2 text-blue-400 hover:text-blue-300 font-semibold text-sm transition-colors duration-200 border border-blue-500/30 hover:border-blue-500/60 px-6 py-3 rounded-2xl hover:bg-blue-500/[0.05]"
          >
            View all services
            <ArrowRight size={15} />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}
