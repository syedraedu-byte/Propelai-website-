'use client'

import { useRef } from 'react'
import Link from 'next/link'
import { motion, useInView } from 'framer-motion'
import { ArrowRight, Calendar, Zap } from 'lucide-react'
import { Button } from '@/components/ui/Button'

export function CTA() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-24 overflow-hidden">
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.97 }}
          animate={isInView ? { opacity: 1, y: 0, scale: 1 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="relative rounded-3xl overflow-hidden"
        >
          {/* Background */}
          <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 via-purple-600/15 to-cyan-600/10" />
          <div className="absolute inset-0 bg-[rgba(5,5,8,0.7)]" />

          {/* Gradient border */}
          <div
            className="absolute inset-0 rounded-3xl"
            style={{
              padding: '1px',
              background: 'linear-gradient(135deg, rgba(59,130,246,0.5), rgba(139,92,246,0.4), rgba(6,182,212,0.3))',
              WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
              WebkitMaskComposite: 'xor',
              maskComposite: 'exclude',
            }}
          />

          {/* Grid background */}
          <div
            className="absolute inset-0 opacity-20"
            style={{
              backgroundImage: 'radial-gradient(rgba(59,130,246,0.15) 1px, transparent 1px)',
              backgroundSize: '24px 24px',
            }}
          />

          {/* Glows inside card */}
          <div
            className="absolute -top-20 left-1/4 w-64 h-64 rounded-full opacity-20"
            style={{ background: 'radial-gradient(#3b82f6, transparent)', filter: 'blur(50px)' }}
          />
          <div
            className="absolute -bottom-20 right-1/4 w-64 h-64 rounded-full opacity-15"
            style={{ background: 'radial-gradient(#8b5cf6, transparent)', filter: 'blur(50px)' }}
          />

          {/* Content */}
          <div className="relative z-10 py-16 px-8 md:px-16 text-center">
            {/* Label */}
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold tracking-widest uppercase font-display bg-blue-500/10 border border-blue-500/25 text-blue-400 mb-7">
              <Zap size={12} className="fill-current" />
              Start Automating Today
            </div>

            {/* Headline */}
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-display font-800 tracking-tight text-white mb-5 leading-[1.08]">
              Ready to eliminate
              <br />
              <span className="gradient-text-full">the repetition?</span>
            </h2>

            <p className="text-slate-400 text-lg max-w-2xl mx-auto font-body leading-relaxed mb-10">
              Book a free 20-minute discovery call. We&apos;ll audit your current processes,
              identify the highest-ROI automation opportunities, and give you a concrete
              roadmap — no fluff, no obligation.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/contact">
                <Button
                  variant="glow"
                  size="xl"
                  icon={<ArrowRight size={20} />}
                  className="font-display font-700 min-w-[240px]"
                >
                  Book Free Discovery Call
                </Button>
              </Link>
              <Link href="/services">
                <Button
                  variant="secondary"
                  size="xl"
                  icon={<Calendar size={18} />}
                  iconPosition="left"
                  className="font-display font-600 min-w-[200px]"
                >
                  View Services
                </Button>
              </Link>
            </div>

            {/* Trust signals */}
            <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-sm text-slate-500 font-body">
              {[
                '✓ Free 20-min call',
                '✓ No obligation',
                '✓ Results in 72hrs',
                '✓ 200+ clients served',
              ].map((item) => (
                <span key={item} className="flex items-center gap-1">
                  {item}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
