'use client'

import { motion } from 'framer-motion'
import { useInView } from 'framer-motion'
import { useRef } from 'react'
import { AnimatedCounter } from '@/components/ui/AnimatedCounter'
import { staggerContainer, fadeInUp } from '@/lib/animations'

const stats = [
  {
    prefix: '$',
    value: 10,
    suffix: 'M+',
    label: 'Revenue Automated',
    description: 'Total business revenue touched by our automation systems',
    color: 'blue',
    delay: 0,
  },
  {
    prefix: '',
    value: 500,
    suffix: '+',
    label: 'Workflows Deployed',
    description: 'Custom automation workflows live across client operations',
    color: 'purple',
    delay: 0.1,
  },
  {
    prefix: '',
    value: 200,
    suffix: '+',
    label: 'Clients Served',
    description: 'From early-stage startups to enterprise operations teams',
    color: 'cyan',
    delay: 0.2,
  },
  {
    prefix: '',
    value: 98,
    suffix: '%',
    label: 'Client Satisfaction',
    description: 'Based on post-project NPS surveys and renewal rates',
    color: 'green',
    delay: 0.3,
  },
]

const colorMap = {
  blue: {
    glow: 'shadow-[0_0_60px_rgba(59,130,246,0.12)]',
    border: 'border-blue-500/20',
    badge: 'bg-blue-500/10 text-blue-400',
    counter: 'text-blue-400',
    divider: 'bg-blue-500/30',
  },
  purple: {
    glow: 'shadow-[0_0_60px_rgba(139,92,246,0.12)]',
    border: 'border-purple-500/20',
    badge: 'bg-purple-500/10 text-purple-400',
    counter: 'text-purple-400',
    divider: 'bg-purple-500/30',
  },
  cyan: {
    glow: 'shadow-[0_0_60px_rgba(6,182,212,0.12)]',
    border: 'border-cyan-500/20',
    badge: 'bg-cyan-500/10 text-cyan-400',
    counter: 'text-cyan-400',
    divider: 'bg-cyan-500/30',
  },
  green: {
    glow: 'shadow-[0_0_60px_rgba(16,185,129,0.12)]',
    border: 'border-emerald-500/20',
    badge: 'bg-emerald-500/10 text-emerald-400',
    counter: 'text-emerald-400',
    divider: 'bg-emerald-500/30',
  },
}

export function Stats() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section ref={ref} className="relative py-20 overflow-hidden">
      {/* Divider lines */}
      <div
        className="absolute top-0 left-0 right-0 h-px opacity-50"
        style={{
          background:
            'linear-gradient(90deg, transparent, rgba(59,130,246,0.5), rgba(139,92,246,0.5), transparent)',
        }}
      />
      <div
        className="absolute bottom-0 left-0 right-0 h-px opacity-30"
        style={{
          background:
            'linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8"
        >
          {stats.map((stat) => {
            const colors = colorMap[stat.color as keyof typeof colorMap]

            return (
              <motion.div
                key={stat.label}
                variants={fadeInUp}
                className={`
                  relative rounded-2xl p-6 lg:p-8 text-center
                  bg-[rgba(255,255,255,0.025)]
                  border ${colors.border}
                  ${colors.glow}
                  transition-all duration-300
                  hover:bg-[rgba(255,255,255,0.04)]
                  overflow-hidden
                  group
                `}
              >
                {/* Background shimmer on hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 shimmer-card" />

                {/* Counter */}
                <div className={`text-4xl lg:text-5xl font-display font-800 mb-2 ${colors.counter}`}>
                  <AnimatedCounter
                    from={0}
                    to={stat.value}
                    prefix={stat.prefix}
                    suffix={stat.suffix}
                    duration={2.2}
                    delay={stat.delay + 0.3}
                  />
                </div>

                {/* Label */}
                <div className="text-white font-display font-600 text-sm lg:text-base mb-2">
                  {stat.label}
                </div>

                {/* Description */}
                <p className="text-slate-500 text-xs leading-relaxed font-body">
                  {stat.description}
                </p>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
