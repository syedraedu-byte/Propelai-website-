'use client'

import { cn } from '@/lib/utils'

interface GridBackgroundProps {
  className?: string
  variant?: 'dots' | 'lines' | 'cross'
  intensity?: 'subtle' | 'medium' | 'strong'
}

export function GridBackground({
  className,
  variant = 'dots',
  intensity = 'subtle',
}: GridBackgroundProps) {
  const opacities = {
    subtle: '0.04',
    medium: '0.08',
    strong: '0.14',
  }
  const op = opacities[intensity]

  if (variant === 'lines') {
    return (
      <div
        className={cn('absolute inset-0 pointer-events-none', className)}
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,${op}) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,${op}) 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }}
      />
    )
  }

  if (variant === 'cross') {
    return (
      <div
        className={cn('absolute inset-0 pointer-events-none', className)}
        style={{
          backgroundImage: `
            linear-gradient(rgba(255,255,255,${op}) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,${op}) 1px, transparent 1px)
          `,
          backgroundSize: '32px 32px',
          backgroundPosition: 'center center',
        }}
      />
    )
  }

  // dots (default)
  return (
    <div
      className={cn('absolute inset-0 pointer-events-none', className)}
      style={{
        backgroundImage: `radial-gradient(rgba(255,255,255,${op}) 1px, transparent 1px)`,
        backgroundSize: '28px 28px',
      }}
    />
  )
}

/* ─── Radial fade overlay (fades edges) ──────────────────────── */
export function GridFade({ className }: { className?: string }) {
  return (
    <div
      className={cn('absolute inset-0 pointer-events-none', className)}
      style={{
        background: `
          radial-gradient(ellipse 80% 60% at 50% 0%, transparent 30%, #050508 90%),
          radial-gradient(ellipse 60% 60% at 0% 50%, transparent 40%, #050508 80%),
          radial-gradient(ellipse 60% 60% at 100% 50%, transparent 40%, #050508 80%)
        `,
      }}
    />
  )
}

/* ─── Glow Orbs (ambient light effects) ─────────────────────── */
export function GlowOrbs() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Top-center blue orb */}
      <div
        className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] rounded-full opacity-[0.12]"
        style={{
          background: 'radial-gradient(ellipse, rgba(59,130,246,1) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
      />
      {/* Bottom-left purple orb */}
      <div
        className="absolute bottom-0 -left-40 w-[500px] h-[400px] rounded-full opacity-[0.10]"
        style={{
          background: 'radial-gradient(ellipse, rgba(139,92,246,1) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
      />
      {/* Bottom-right cyan orb */}
      <div
        className="absolute bottom-0 -right-40 w-[400px] h-[300px] rounded-full opacity-[0.08]"
        style={{
          background: 'radial-gradient(ellipse, rgba(6,182,212,1) 0%, transparent 70%)',
          filter: 'blur(80px)',
        }}
      />
    </div>
  )
}
