import type { Metadata } from 'next'
import { ServicesHero } from './ServicesHero'
import { ServiceDetail } from './ServiceDetail'
import { CTA } from '@/components/sections/CTA'

export const metadata: Metadata = {
  title: 'Services — AI Automation, Chatbots, Voice Agents & More',
  description:
    'Full-stack AI automation services: workflow automation, AI chatbots, voice agents, CRM integration, lead generation systems, and email automation.',
}

export default function ServicesPage() {
  return (
    <>
      <ServicesHero />
      <ServiceDetail />
      <CTA />
    </>
  )
}
