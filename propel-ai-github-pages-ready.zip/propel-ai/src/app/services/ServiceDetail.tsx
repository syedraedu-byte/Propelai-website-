'use client'

import { useRef } from 'react'
import Link from 'next/link'
import { motion, useInView } from 'framer-motion'
import {
  Bot, GitBranch, Users, Mic2, TrendingUp,
  Mail, Database, ArrowRight, CheckCircle2, Zap
} from 'lucide-react'
import { GlowCard } from '@/components/ui/GlowCard'
import { staggerContainer, fadeInUp, fadeInLeft, fadeInRight } from '@/lib/animations'

const serviceDetails = [
  {
    id: 'ai-automation',
    icon: Bot,
    title: 'AI Automation Systems',
    subtitle: 'Replace manual work with intelligent pipelines',
    description:
      'We architect end-to-end automation systems that handle complex, multi-step business processes with AI decision-making at every stage. From data ingestion to output actions — every step is automated, monitored, and optimized.',
    outcomes: [
      '80%+ reduction in manual processing time',
      'Zero human errors in repetitive data tasks',
      'Automated exception handling & escalations',
      'Real-time monitoring & alerting dashboards',
      '24/7 operation with zero downtime',
    ],
    useCases: [
      'Automated invoice processing & routing',
      'AI-powered document classification',
      'Multi-step lead nurturing workflows',
      'Inventory & operations management',
    ],
    tools: ['Make.com', 'n8n', 'OpenAI', 'Claude API', 'Zapier'],
    color: 'blue',
    gradient: 'from-blue-500/10 to-transparent',
    iconBg: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    reverse: false,
  },
  {
    id: 'chatbots',
    icon: Users,
    title: 'AI Chatbots & Agents',
    subtitle: 'Deploy intelligent 24/7 customer-facing AI',
    description:
      'We build custom AI chatbots and agents trained on your business content — your products, FAQs, pricing, and processes. They handle customer support, lead qualification, onboarding, and appointment booking with human-level accuracy.',
    outcomes: [
      '70%+ reduction in support ticket volume',
      '24/7 availability across all channels',
      'Human-like conversation quality',
      'Seamless handoff to live agents',
      'Multi-language support',
    ],
    useCases: [
      'Customer support deflection',
      'Lead qualification & scoring',
      'Product recommendation engines',
      'Onboarding & FAQ resolution',
    ],
    tools: ['OpenAI GPT-4', 'Claude', 'Voiceflow', 'Botpress', 'WhatsApp API'],
    color: 'purple',
    gradient: 'from-purple-500/10 to-transparent',
    iconBg: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    reverse: true,
  },
  {
    id: 'voice-agents',
    icon: Mic2,
    title: 'AI Voice Agents',
    subtitle: 'Natural-sounding AI that handles calls at scale',
    description:
      'Deploy AI voice agents for inbound and outbound calls using Vapi.ai or Bland.ai. Handle lead qualification, appointment booking, customer queries, and follow-up calls — simultaneously, at unlimited scale, with natural-sounding speech.',
    outcomes: [
      'Handle 100s of simultaneous calls',
      'Lead qualification at massive scale',
      'Instant CRM updates post-call',
      'Consistent pitch & message delivery',
      'Full call recording & transcription',
    ],
    useCases: [
      'Real estate inquiry handling',
      'Sales outreach & qualification',
      'Appointment reminder calls',
      'Post-purchase follow-up',
    ],
    tools: ['Vapi.ai', 'Bland.ai', 'ElevenLabs', 'Twilio', 'Make.com'],
    color: 'cyan',
    gradient: 'from-cyan-500/10 to-transparent',
    iconBg: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20',
    reverse: false,
  },
  {
    id: 'crm',
    icon: Database,
    title: 'CRM Automation',
    subtitle: 'Your CRM running itself, intelligently',
    description:
      'We connect your CRM to your entire business operation — automating deal stage updates, contact scoring, follow-up sequences, rep notifications, and pipeline reporting. Your team focuses on selling; the CRM handles the admin.',
    outcomes: [
      '100% elimination of manual data entry',
      'Automated deal stage progression',
      'AI-powered contact scoring',
      'Real-time rep alerting system',
      'Automated pipeline forecasting',
    ],
    useCases: [
      'HubSpot / Salesforce automation',
      'Auto-enriched contact profiles',
      'Deal stage trigger workflows',
      'Revenue attribution tracking',
    ],
    tools: ['HubSpot', 'Salesforce', 'Pipedrive', 'Make.com', 'Clay'],
    color: 'violet',
    gradient: 'from-violet-500/10 to-transparent',
    iconBg: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
    reverse: true,
  },
  {
    id: 'leads',
    icon: TrendingUp,
    title: 'Lead Generation Systems',
    subtitle: 'A predictable, AI-powered lead engine',
    description:
      'Build a fully automated inbound lead engine — from scraping and enrichment to scoring and CRM routing. Every lead is validated, enriched with intent data, and delivered to your sales team warm and ready to close.',
    outcomes: [
      '5× increase in qualified lead volume',
      'Automated enrichment & scoring',
      'Intent-based lead prioritization',
      'Direct CRM routing & assignment',
      'Daily lead pipeline reporting',
    ],
    useCases: [
      'B2B outbound prospecting',
      'Real estate lead qualification',
      'E-commerce retargeting flows',
      'SaaS trial-to-paid nurturing',
    ],
    tools: ['Apollo.io', 'Hunter.io', 'Clay', 'Make.com', 'HubSpot'],
    color: 'green',
    gradient: 'from-emerald-500/10 to-transparent',
    iconBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    reverse: false,
  },
  {
    id: 'email',
    icon: Mail,
    title: 'AI Email Automation',
    subtitle: 'Personalized emails at impossible scale',
    description:
      'We build behavior-triggered, AI-personalized email sequences that respond to user actions, purchase history, and engagement signals. Every email feels hand-written; every sequence is fully automatic.',
    outcomes: [
      '45%+ higher open rates',
      '1:1 personalization at scale',
      'Behavior-triggered send logic',
      'A/B testing automation',
      'Revenue attribution per email',
    ],
    useCases: [
      'SaaS onboarding sequences',
      'E-commerce abandoned cart flows',
      'Re-engagement campaigns',
      'Coaching/course nurture sequences',
    ],
    tools: ['Instantly.ai', 'Smartlead', 'Klaviyo', 'Make.com', 'OpenAI'],
    color: 'amber',
    gradient: 'from-amber-500/10 to-transparent',
    iconBg: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    reverse: true,
  },
]

const colorAccentMap: Record<string, string> = {
  blue: 'text-blue-400',
  purple: 'text-purple-400',
  cyan: 'text-cyan-400',
  violet: 'text-violet-400',
  green: 'text-emerald-400',
  amber: 'text-amber-400',
}

function ServiceRow({ service, index }: { service: typeof serviceDetails[0]; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })
  const Icon = service.icon
  const accent = colorAccentMap[service.color] || 'text-blue-400'

  return (
    <div ref={ref} id={service.id} className="py-16 scroll-mt-24">
      {/* Divider */}
      {index > 0 && (
        <div className="h-px bg-white/[0.05] mb-16" />
      )}

      <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${service.reverse ? 'lg:[&>*:first-child]:order-last' : ''}`}>
        {/* Text side */}
        <motion.div
          initial={{ opacity: 0, x: service.reverse ? 40 : -40 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94] }}
        >
          {/* Icon */}
          <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center mb-6 ${service.iconBg}`}>
            <Icon size={26} />
          </div>

          {/* Subtitle */}
          <div className={`text-xs font-display font-700 tracking-widest uppercase mb-3 ${accent}`}>
            {service.subtitle}
          </div>

          {/* Title */}
          <h2 className="text-3xl sm:text-4xl font-display font-800 tracking-tight text-white leading-[1.1] mb-5">
            {service.title}
          </h2>

          {/* Description */}
          <p className="text-slate-400 text-base leading-relaxed font-body mb-8">
            {service.description}
          </p>

          {/* Outcomes */}
          <div className="mb-8">
            <div className="text-xs font-display font-700 tracking-widest uppercase text-slate-500 mb-3">
              Business Outcomes
            </div>
            <ul className="flex flex-col gap-2.5">
              {service.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-2.5 text-sm text-slate-300 font-body">
                  <CheckCircle2 size={15} className={`mt-0.5 flex-shrink-0 ${accent}`} />
                  {o}
                </li>
              ))}
            </ul>
          </div>

          {/* Tools */}
          <div className="flex flex-wrap gap-2 mb-8">
            {service.tools.map((tool) => (
              <span key={tool} className="px-3 py-1.5 rounded-xl text-xs font-semibold font-display bg-white/[0.04] border border-white/[0.08] text-slate-300">
                {tool}
              </span>
            ))}
          </div>

          <Link
            href="/contact"
            className={`inline-flex items-center gap-2 text-sm font-semibold ${accent} transition-all duration-200 group`}
          >
            Start this project
            <ArrowRight size={15} className="group-hover:translate-x-1 transition-transform duration-200" />
          </Link>
        </motion.div>

        {/* Visual card side */}
        <motion.div
          initial={{ opacity: 0, x: service.reverse ? -40 : 40 }}
          animate={isInView ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.7, ease: [0.25, 0.46, 0.45, 0.94], delay: 0.15 }}
        >
          <GlowCard
            className={`p-8 bg-gradient-to-br ${service.gradient}`}
            glowColor={`rgba(59,130,246,0.1)`}
          >
            {/* Use cases */}
            <div className="mb-6">
              <div className="text-xs font-display font-700 tracking-widest uppercase text-slate-500 mb-4">
                Common Use Cases
              </div>
              <div className="grid grid-cols-1 gap-3">
                {service.useCases.map((uc, i) => (
                  <div key={uc} className="flex items-center gap-3 p-3.5 rounded-xl bg-white/[0.03] border border-white/[0.05] group hover:bg-white/[0.05] transition-colors duration-200">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-display font-700 ${service.iconBg} border flex-shrink-0`}>
                      {String(i + 1).padStart(2, '0')}
                    </div>
                    <span className="text-sm text-slate-300 font-body">{uc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA inside card */}
            <div className="pt-5 border-t border-white/[0.06] flex items-center justify-between">
              <div>
                <div className="text-white font-display font-600 text-sm">Ready to deploy?</div>
                <div className="text-slate-500 text-xs font-body">Live in as fast as 72 hours</div>
              </div>
              <div className={`w-9 h-9 rounded-xl border flex items-center justify-center ${service.iconBg}`}>
                <Zap size={16} />
              </div>
            </div>
          </GlowCard>
        </motion.div>
      </div>
    </div>
  )
}

export function ServiceDetail() {
  return (
    <section className="relative py-8 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {serviceDetails.map((service, i) => (
          <ServiceRow key={service.id} service={service} index={i} />
        ))}
      </div>
    </section>
  )
}
