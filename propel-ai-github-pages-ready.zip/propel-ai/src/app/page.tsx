import type { Metadata } from 'next'
import { Hero } from '@/components/sections/Hero'
import { LogoMarquee } from '@/components/sections/LogoMarquee'
import { Stats } from '@/components/sections/Stats'
import { Features } from '@/components/sections/Features'
import { Services } from '@/components/sections/Services'
import { Process } from '@/components/sections/Process'
import { Testimonials } from '@/components/sections/Testimonials'
import { Pricing } from '@/components/sections/Pricing'
import { FAQ } from '@/components/sections/FAQ'
import { CTA } from '@/components/sections/CTA'

export const metadata: Metadata = {
  title: 'Propel AI — Automate Growth. Eliminate Repetition.',
  description:
    'Elite AI automation agency deploying intelligent agents, workflow automation, CRM integrations, and lead systems for fast-growing businesses.',
}

export default function HomePage() {
  return (
    <>
      <Hero />
      <LogoMarquee />
      <Stats />
      <Features />
      <Services />
      <Process />
      <Testimonials />
      <Pricing />
      <FAQ />
      <CTA />
    </>
  )
}
