import Link from 'next/link'
import { GridBackground } from '@/components/effects/GridBackground'

export default function NotFound() {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <GridBackground variant="dots" intensity="subtle" />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 60% 40% at 50% 40%, rgba(59,130,246,0.08), transparent)',
        }}
      />
      <div className="relative z-10 text-center px-6">
        <div className="text-[8rem] sm:text-[12rem] font-display font-800 leading-none gradient-text opacity-20 select-none">
          404
        </div>
        <h1 className="text-3xl sm:text-4xl font-display font-800 text-white mb-4 -mt-4 tracking-tight">
          Page not found
        </h1>
        <p className="text-slate-400 font-body mb-8 max-w-sm mx-auto">
          This page doesn&apos;t exist — but your automation journey can start right here.
        </p>
        <Link
          href="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-blue-500 hover:bg-blue-600 text-white font-display font-600 text-sm transition-colors duration-200"
        >
          ← Back to Home
        </Link>
      </div>
    </div>
  )
}
