'use client'

import { motion } from 'framer-motion'
import { Badge } from '@/components/ui/Badge'
import { GridBackground, GlowOrbs } from '@/components/effects/GridBackground'

export function ContactHero() {
  return (
    <section className="relative pt-36 pb-20 overflow-hidden">
      <GridBackground variant="cross" intensity="subtle" />
      <GlowOrbs />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 70% 50% at 50% 0%, rgba(6,182,212,0.09), transparent)',
        }}
      />

      <div className="relative z-10 max-w-3xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-6"
        >
          <Badge variant="cyan" dot>Let&apos;s Talk</Badge>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl sm:text-6xl lg:text-7xl font-display font-800 tracking-tight text-white leading-[1.06] mb-6"
        >
          Start your
          <br />
          <span className="gradient-text">automation journey</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-slate-400 text-xl max-w-xl mx-auto font-body leading-relaxed"
        >
          Book a free 20-minute discovery call. No pitch, no pressure — just
          a direct conversation about what to automate first.
        </motion.p>
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{ background: 'linear-gradient(to bottom, transparent, #050508)' }}
      />
    </section>
  )
}
