import type { Metadata } from 'next'
import { ContactHero } from './ContactHero'
import { ContactContent } from './ContactContent'

export const metadata: Metadata = {
  title: 'Contact — Book a Free Discovery Call',
  description:
    'Ready to automate? Book a free 20-minute discovery call with Propel AI. We\'ll audit your processes and map out your automation roadmap.',
}

export default function ContactPage() {
  return (
    <>
      <ContactHero />
      <ContactContent />
    </>
  )
}
