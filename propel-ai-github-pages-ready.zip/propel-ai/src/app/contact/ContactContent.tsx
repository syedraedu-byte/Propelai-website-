'use client'

import { useRef, useState, FormEvent } from 'react'
import { motion, useInView } from 'framer-motion'
import {
  Mail, Phone, MapPin, Calendar, Send, CheckCircle2,
  Clock, MessageSquare, Building2, User, Zap
} from 'lucide-react'
import { Button } from '@/components/ui/Button'
import { GlowCard } from '@/components/ui/GlowCard'
import { staggerContainer, fadeInUp, fadeInLeft, fadeInRight } from '@/lib/animations'

const services = [
  'AI Automation System',
  'AI Chatbot / Agent',
  'AI Voice Agent',
  'CRM Automation',
  'Lead Generation System',
  'Email Automation',
  'Workflow Optimization',
  'Not sure yet',
]

const contactInfo = [
  {
    icon: Mail,
    label: 'Email',
    value: 'hello@propelai.agency',
    href: 'mailto:hello@propelai.agency',
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  },
  {
    icon: Phone,
    label: 'WhatsApp',
    value: '+91 98765 43210',
    href: 'https://wa.me/919876543210',
    color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  },
  {
    icon: MapPin,
    label: 'Location',
    value: 'Hyderabad, India · Remote Worldwide',
    href: null,
    color: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  },
  {
    icon: Clock,
    label: 'Response Time',
    value: 'Within 4 hours on weekdays',
    href: null,
    color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  },
]

const bookingSlots = [
  { label: 'Today, 2:00 PM', available: true },
  { label: 'Today, 4:30 PM', available: true },
  { label: 'Tomorrow, 10:00 AM', available: true },
  { label: 'Tomorrow, 1:00 PM', available: false },
  { label: 'Wed, 11:00 AM', available: true },
  { label: 'Wed, 3:00 PM', available: true },
]

type FormState = 'idle' | 'loading' | 'success' | 'error'

export function ContactContent() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-60px' })

  const [formState, setFormState] = useState<FormState>('idle')
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null)
  const [selectedService, setSelectedService] = useState<string>('')
  const [form, setForm] = useState({
    name: '', email: '', company: '', message: '',
  })

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setFormState('loading')
    // Simulate API call
    await new Promise((r) => setTimeout(r, 1500))
    setFormState('success')
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  return (
    <section ref={ref} className="relative py-12 pb-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">

          {/* ── Left column: info + booking ────────────────────── */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="lg:col-span-2 flex flex-col gap-6"
          >
            {/* Contact info */}
            <GlowCard className="p-7">
              <div className="text-xs font-display font-700 tracking-widest uppercase text-slate-500 mb-5">
                Contact Information
              </div>
              <div className="flex flex-col gap-4">
                {contactInfo.map(({ icon: Icon, label, value, href, color }) => (
                  <div key={label} className="flex items-center gap-3.5">
                    <div className={`w-9 h-9 rounded-xl border flex items-center justify-center flex-shrink-0 ${color}`}>
                      <Icon size={15} />
                    </div>
                    <div>
                      <div className="text-slate-500 text-xs font-body">{label}</div>
                      {href ? (
                        <a href={href} className="text-slate-200 text-sm font-body hover:text-white transition-colors duration-200">
                          {value}
                        </a>
                      ) : (
                        <span className="text-slate-200 text-sm font-body">{value}</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </GlowCard>

            {/* Quick booking slots */}
            <GlowCard className="p-7" glowColor="rgba(59,130,246,0.12)">
              <div className="flex items-center gap-2 mb-5">
                <Calendar size={15} className="text-blue-400" />
                <div className="text-xs font-display font-700 tracking-widest uppercase text-slate-500">
                  Book a Slot
                </div>
              </div>
              <p className="text-slate-400 text-xs font-body mb-5 leading-relaxed">
                Pick a convenient time for your free 20-minute discovery call.
              </p>
              <div className="grid grid-cols-2 gap-2">
                {bookingSlots.map((slot) => (
                  <button
                    key={slot.label}
                    onClick={() => slot.available && setSelectedSlot(slot.label)}
                    disabled={!slot.available}
                    className={`
                      px-3 py-2.5 rounded-xl text-xs font-display font-600 text-left transition-all duration-200
                      ${!slot.available
                        ? 'opacity-30 cursor-not-allowed bg-white/[0.02] border border-white/[0.05] text-slate-500'
                        : selectedSlot === slot.label
                        ? 'bg-blue-500/20 border border-blue-500/50 text-blue-300'
                        : 'bg-white/[0.04] border border-white/[0.08] text-slate-300 hover:bg-white/[0.07] hover:border-white/[0.15]'
                      }
                    `}
                  >
                    {slot.available ? (
                      <span className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0" />
                        {slot.label}
                      </span>
                    ) : (
                      <span className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-slate-600 flex-shrink-0" />
                        {slot.label}
                      </span>
                    )}
                  </button>
                ))}
              </div>
              {selectedSlot && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-4 p-3 rounded-xl bg-blue-500/10 border border-blue-500/25 text-blue-300 text-xs font-body flex items-center gap-2"
                >
                  <CheckCircle2 size={13} className="text-blue-400" />
                  Slot selected: <strong>{selectedSlot}</strong>
                </motion.div>
              )}
            </GlowCard>

            {/* Map placeholder */}
            <GlowCard className="p-0 overflow-hidden h-40">
              <div
                className="w-full h-full flex items-center justify-center relative"
                style={{
                  background: 'radial-gradient(ellipse at 50% 60%, rgba(59,130,246,0.08), transparent 70%), linear-gradient(135deg, #0a0a14, #050508)',
                  backgroundImage: `radial-gradient(rgba(255,255,255,0.04) 1px, transparent 1px)`,
                  backgroundSize: '20px 20px',
                }}
              >
                <div className="text-center">
                  <MapPin size={24} className="text-blue-400 mx-auto mb-2" />
                  <p className="text-slate-400 text-xs font-body">Hyderabad, India</p>
                  <p className="text-slate-600 text-xs font-body">Remote worldwide</p>
                </div>
                {/* Glow dot */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3">
                  <span className="absolute inset-0 rounded-full bg-blue-500 animate-ping opacity-40" />
                  <span className="relative flex w-3 h-3 rounded-full bg-blue-500" />
                </div>
              </div>
            </GlowCard>
          </motion.div>

          {/* ── Right column: form ──────────────────────────────── */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-3"
          >
            <GlowCard className="p-8 lg:p-10 h-full" glowColor="rgba(139,92,246,0.1)">
              {formState === 'success' ? (
                /* Success state */
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center h-full min-h-[400px] text-center"
                >
                  <div className="w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mb-6">
                    <CheckCircle2 size={36} className="text-emerald-400" />
                  </div>
                  <h3 className="text-2xl font-display font-800 text-white mb-3">Message received!</h3>
                  <p className="text-slate-400 font-body text-base max-w-xs leading-relaxed mb-6">
                    We&apos;ll review your project and get back to you within 4 hours. Check your email for a confirmation.
                  </p>
                  <div className="flex items-center gap-2 text-sm text-blue-400">
                    <Zap size={14} />
                    <span>Expected response: Within 4 hours</span>
                  </div>
                </motion.div>
              ) : (
                /* Form */
                <form onSubmit={handleSubmit} className="flex flex-col gap-6">
                  <div>
                    <div className="text-xs font-display font-700 tracking-widest uppercase text-slate-500 mb-1">
                      Send us a message
                    </div>
                    <h2 className="text-2xl font-display font-800 text-white tracking-tight">
                      Tell us about your project
                    </h2>
                  </div>

                  {/* Name + Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 font-display mb-2">
                        Full Name *
                      </label>
                      <div className="relative">
                        <User size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                        <input
                          type="text"
                          name="name"
                          required
                          value={form.name}
                          onChange={handleChange}
                          placeholder="Your name"
                          className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.09] text-white text-sm font-body placeholder:text-slate-600 focus:outline-none focus:border-blue-500/50 focus:bg-white/[0.06] transition-all duration-200"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 font-display mb-2">
                        Work Email *
                      </label>
                      <div className="relative">
                        <Mail size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                        <input
                          type="email"
                          name="email"
                          required
                          value={form.email}
                          onChange={handleChange}
                          placeholder="you@company.com"
                          className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.09] text-white text-sm font-body placeholder:text-slate-600 focus:outline-none focus:border-blue-500/50 focus:bg-white/[0.06] transition-all duration-200"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Company */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 font-display mb-2">
                      Company / Organization
                    </label>
                    <div className="relative">
                      <Building2 size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        type="text"
                        name="company"
                        value={form.company}
                        onChange={handleChange}
                        placeholder="Your company name"
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.09] text-white text-sm font-body placeholder:text-slate-600 focus:outline-none focus:border-blue-500/50 focus:bg-white/[0.06] transition-all duration-200"
                      />
                    </div>
                  </div>

                  {/* Service selector */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 font-display mb-2">
                      What do you need? *
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {services.map((s) => (
                        <button
                          key={s}
                          type="button"
                          onClick={() => setSelectedService(s)}
                          className={`
                            px-3.5 py-2 rounded-xl text-xs font-display font-600 transition-all duration-200
                            ${selectedService === s
                              ? 'bg-blue-500/20 border border-blue-500/50 text-blue-300'
                              : 'bg-white/[0.04] border border-white/[0.08] text-slate-400 hover:text-white hover:bg-white/[0.07]'
                            }
                          `}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 font-display mb-2">
                      Message *
                    </label>
                    <div className="relative">
                      <MessageSquare size={14} className="absolute left-3.5 top-3.5 text-slate-500" />
                      <textarea
                        name="message"
                        required
                        value={form.message}
                        onChange={handleChange}
                        rows={4}
                        placeholder="Tell us about your current process, what you want to automate, and your expected outcome…"
                        className="w-full pl-10 pr-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.09] text-white text-sm font-body placeholder:text-slate-600 focus:outline-none focus:border-blue-500/50 focus:bg-white/[0.06] transition-all duration-200 resize-none"
                      />
                    </div>
                  </div>

                  {/* Submit */}
                  <div className="flex items-center justify-between gap-4 flex-wrap">
                    <p className="text-slate-600 text-xs font-body">
                      We respond within 4 hours on weekdays.
                    </p>
                    <Button
                      type="submit"
                      variant="glow"
                      size="lg"
                      loading={formState === 'loading'}
                      icon={formState !== 'loading' ? <Send size={16} /> : undefined}
                      className="font-display font-600 min-w-[160px]"
                    >
                      {formState === 'loading' ? 'Sending…' : 'Send Message'}
                    </Button>
                  </div>
                </form>
              )}
            </GlowCard>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
