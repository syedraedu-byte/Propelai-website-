import type { Metadata, Viewport } from 'next'
import { Sora, Manrope } from 'next/font/google'
import './globals.css'
import { Navbar } from '@/components/layout/Navbar'
import { Footer } from '@/components/layout/Footer'
import { ScrollProgress } from '@/components/effects/ScrollProgress'

/* ─── Fonts ──────────────────────────────────────────────────── */
const sora = Sora({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-sora',
  display: 'swap',
})

const manrope = Manrope({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-manrope',
  display: 'swap',
})

/* ─── SEO Metadata ───────────────────────────────────────────── */
export const metadata: Metadata = {
  title: {
    default: 'Propel AI — Automate Growth. Eliminate Repetition.',
    template: '%s | Propel AI',
  },
  description:
    'Propel AI is an elite AI automation agency helping fast-growing startups and enterprises automate workflows, deploy AI agents, chatbots, CRM systems, and lead generation — at scale.',
  keywords: [
    'AI automation agency',
    'AI agents',
    'workflow automation',
    'CRM automation',
    'AI chatbots',
    'lead generation AI',
    'business automation',
    'AI voice agents',
    'Make.com automation',
    'n8n workflows',
  ],
  authors: [{ name: 'Propel AI', url: 'https://propelai.agency' }],
  creator: 'Propel AI',
  publisher: 'Propel AI',
  metadataBase: new URL('https://propelai.agency'),
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://propelai.agency',
    siteName: 'Propel AI',
    title: 'Propel AI — Automate Growth. Eliminate Repetition.',
    description:
      'Elite AI automation agency deploying intelligent agents, workflow automation, and CRM integrations for high-growth businesses.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Propel AI — AI Automation Agency',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Propel AI — AI Automation Agency',
    description: 'Automate Growth. Eliminate Repetition. Elite AI automation for fast-growing businesses.',
    images: ['/og-image.png'],
    creator: '@propelai',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/site.webmanifest',
}

export const viewport: Viewport = {
  themeColor: '#050508',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
}

/* ─── Root Layout ────────────────────────────────────────────── */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html
      lang="en"
      className={`${sora.variable} ${manrope.variable} scroll-smooth`}
      suppressHydrationWarning
    >
      <body className="bg-[#050508] text-slate-100 font-body overflow-x-hidden antialiased">
        <ScrollProgress />
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
