'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { Target, Eye, Heart, Zap } from 'lucide-react'
import { AnimatedCounter } from '@/components/ui/AnimatedCounter'
import { GlowCard } from '@/components/ui/GlowCard'
import { staggerContainer, fadeInUp } from '@/lib/animations'

const values = [
  {
    icon: Target,
    title: 'Outcome-Obsessed',
    description:
      'We measure our success by your results — not by the complexity of what we build. Every system ships with defined KPIs and ROI tracking from day one.',
    color: 'blue',
  },
  {
    icon: Zap,
    title: 'Speed Without Sacrifice',
    description:
      'We deploy production-grade systems in 72 hours because we\'ve engineered a delivery process that eliminates waste — not quality. Fast and excellent is our standard.',
    color: 'purple',
  },
  {
    icon: Eye,
    title: 'Radical Transparency',
    description:
      'No black boxes. Every automation we build is fully documented, monitored, and handed over with complete training. You own what we build — completely.',
    color: 'cyan',
  },
  {
    icon: Heart,
    title: 'Long-Term Partnership',
    description:
      'We don\'t disappear after launch. Our best client relationships have grown over years as we expand automation across their entire operation, function by function.',
    color: 'green',
  },
]

const iconColorMap: Record<string, string> = {
  blue: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
  purple: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  cyan: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  green: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
}

const impactStats = [
  { value: 10, prefix: '$', suffix: 'M+', label: 'Revenue automated' },
  { value: 500, prefix: '', suffix: '+', label: 'Workflows deployed' },
  { value: 200, prefix: '', suffix: '+', label: 'Clients served' },
  { value: 72, prefix: '', suffix: 'hrs', label: 'Avg. deploy time' },
]

export function Mission() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">

        {/* Mission / Vision split */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-20"
        >
          <GlowCard className="p-8 lg:p-10" glowColor="rgba(59,130,246,0.12)">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center mb-5">
              <Target size={20} />
            </div>
            <div className="text-xs font-display font-700 tracking-widest uppercase text-blue-400 mb-3">
              Our Mission
            </div>
            <h3 className="text-2xl font-display font-800 text-white tracking-tight mb-4 leading-snug">
              Free every business from the chains of manual operations
            </h3>
            <p className="text-slate-400 font-body leading-relaxed text-sm">
              We believe the most valuable companies in the next decade will be the ones that
              automate their operations fastest. Our mission is to give every business — from
              ambitious startups to established enterprises — access to the same AI automation
              infrastructure that Fortune 500 companies build internal teams to create.
            </p>
          </GlowCard>

          <GlowCard className="p-8 lg:p-10" glowColor="rgba(139,92,246,0.12)">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-5">
              <Eye size={20} />
            </div>
            <div className="text-xs font-display font-700 tracking-widest uppercase text-purple-400 mb-3">
              Our Vision
            </div>
            <h3 className="text-2xl font-display font-800 text-white tracking-tight mb-4 leading-snug">
              A world where humans do only the work only humans can do
            </h3>
            <p className="text-slate-400 font-body leading-relaxed text-sm">
              Repetitive work robs people of creativity, strategy, and joy. We envision a future
              where AI handles the operational layer entirely — and human talent focuses exclusively
              on relationships, creativity, and high-leverage decisions. We&apos;re building that
              future, one automation at a time.
            </p>
          </GlowCard>
        </motion.div>

        {/* Impact stats bar */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20"
        >
          {impactStats.map((stat, i) => (
            <div key={stat.label} className="text-center p-6 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
              <div className="text-4xl font-display font-800 gradient-text mb-1">
                <AnimatedCounter
                  from={0}
                  to={stat.value}
                  prefix={stat.prefix}
                  suffix={stat.suffix}
                  duration={2}
                  delay={i * 0.1 + 0.3}
                />
              </div>
              <div className="text-slate-500 text-sm font-body">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Values grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-center mb-10"
        >
          <h2 className="text-3xl sm:text-4xl font-display font-800 text-white tracking-tight mb-3">
            What we stand for
          </h2>
          <p className="text-slate-400 font-body text-base max-w-xl mx-auto">
            Four principles that govern every project, every client relationship, every line of code.
          </p>
        </motion.div>

        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-1 sm:grid-cols-2 gap-5"
        >
          {values.map((value) => {
            const Icon = value.icon
            const iconClasses = iconColorMap[value.color]
            return (
              <motion.div key={value.title} variants={fadeInUp}>
                <GlowCard className="p-7 group hover:-translate-y-1 transition-transform duration-300 h-full">
                  <div className={`w-11 h-11 rounded-2xl border flex items-center justify-center mb-4 ${iconClasses} group-hover:scale-110 transition-transform duration-300`}>
                    <Icon size={20} />
                  </div>
                  <h3 className="text-white font-display font-700 text-lg mb-2 tracking-tight">
                    {value.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed font-body">
                    {value.description}
                  </p>
                </GlowCard>
              </motion.div>
            )
          })}
        </motion.div>
      </div>
    </section>
  )
}
