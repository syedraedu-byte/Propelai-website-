'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { Twitter, Linkedin, Globe } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import { GlowCard } from '@/components/ui/GlowCard'
import { staggerContainer, fadeInUp } from '@/lib/animations'

const team = [
  {
    name: 'Raed Al-Hassan',
    role: 'Founder & CEO',
    bio: 'AI automation architect and entrepreneur. Built his first automation system at 17. Obsessed with eliminating operational waste using intelligent systems.',
    avatar: 'RA',
    gradient: 'from-blue-500 to-purple-600',
    skills: ['AI Strategy', 'Automation Architecture', 'Client Growth'],
    socials: { twitter: '#', linkedin: '#' },
    quote: '"The best process is one that runs itself."',
  },
  {
    name: 'Aryan Sharma',
    role: 'Head of Automation',
    bio: '3 years building Make.com and n8n workflows for enterprise clients. Expert in connecting any tool to any other tool and making complex ops simple.',
    avatar: 'AS',
    gradient: 'from-purple-500 to-pink-600',
    skills: ['Make.com', 'n8n', 'API Integration'],
    socials: { twitter: '#', linkedin: '#' },
    quote: '"If a human does it twice, we automate it."',
  },
  {
    name: 'Shreya Kapoor',
    role: 'AI Engineer',
    bio: 'Former ML engineer turned automation specialist. Builds the AI decision layers, prompt systems, and agent architectures that power our most complex deployments.',
    avatar: 'SK',
    gradient: 'from-cyan-500 to-blue-600',
    skills: ['LLM Engineering', 'AI Agents', 'RAG Systems'],
    socials: { twitter: '#', linkedin: '#' },
    quote: '"Great AI is invisible. It just works."',
  },
  {
    name: 'Dev Patel',
    role: 'Voice AI Specialist',
    bio: 'Deploys AI voice agents that handle hundreds of calls simultaneously. Builds on Vapi.ai and Bland.ai — and has deployed voice systems for real estate, coaching, and SaaS.',
    avatar: 'DP',
    gradient: 'from-emerald-500 to-cyan-600',
    skills: ['Vapi.ai', 'Bland.ai', 'Call Flow Design'],
    socials: { twitter: '#', linkedin: '#' },
    quote: '"Voice AI is 3 years ahead of where most people think."',
  },
]

export function TeamSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Badge variant="cyan" className="mb-5">✦ The Team</Badge>
          <h2 className="text-4xl sm:text-5xl font-display font-800 tracking-tight text-white mb-4 leading-[1.08]">
            Built by people who
            <br />
            <span className="gradient-text">live and breathe AI</span>
          </h2>
          <p className="text-slate-400 text-lg font-body max-w-xl mx-auto">
            A lean, elite team of automation architects, AI engineers, and growth specialists.
          </p>
        </motion.div>

        {/* Team grid */}
        <motion.div
          initial="hidden"
          animate={isInView ? 'visible' : 'hidden'}
          variants={staggerContainer}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5"
        >
          {team.map((member) => (
            <motion.div key={member.name} variants={fadeInUp}>
              <GlowCard className="p-6 group hover:-translate-y-2 transition-transform duration-300 h-full flex flex-col">
                {/* Avatar */}
                <div className="mb-5">
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${member.gradient} flex items-center justify-center text-white font-display font-700 text-lg shadow-[0_4px_20px_rgba(0,0,0,0.3)] group-hover:scale-110 transition-transform duration-300`}>
                    {member.avatar}
                  </div>
                </div>

                {/* Info */}
                <div className="flex-1">
                  <h3 className="text-white font-display font-700 text-base mb-0.5">{member.name}</h3>
                  <div className="text-slate-500 text-xs font-body mb-3">{member.role}</div>
                  <p className="text-slate-400 text-xs leading-relaxed font-body mb-4">{member.bio}</p>

                  {/* Skills */}
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {member.skills.map((skill) => (
                      <span key={skill} className="text-[10px] font-display font-600 px-2 py-1 rounded-lg bg-white/[0.04] border border-white/[0.07] text-slate-400">
                        {skill}
                      </span>
                    ))}
                  </div>

                  {/* Quote */}
                  <p className="text-slate-600 text-xs italic font-body leading-relaxed">
                    {member.quote}
                  </p>
                </div>

                {/* Socials */}
                <div className="flex items-center gap-2 mt-5 pt-4 border-t border-white/[0.06]">
                  <a href={member.socials.twitter} className="w-7 h-7 rounded-lg bg-white/[0.04] border border-white/[0.07] flex items-center justify-center text-slate-500 hover:text-white hover:bg-white/[0.08] transition-all duration-200">
                    <Twitter size={12} />
                  </a>
                  <a href={member.socials.linkedin} className="w-7 h-7 rounded-lg bg-white/[0.04] border border-white/[0.07] flex items-center justify-center text-slate-500 hover:text-white hover:bg-white/[0.08] transition-all duration-200">
                    <Linkedin size={12} />
                  </a>
                </div>
              </GlowCard>
            </motion.div>
          ))}
        </motion.div>

        {/* Hiring banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.7, duration: 0.5 }}
          className="mt-10 p-7 rounded-2xl glass border border-white/[0.07] flex flex-col sm:flex-row items-center justify-between gap-5 text-center sm:text-left"
        >
          <div>
            <h3 className="text-white font-display font-700 text-lg mb-1">
              We&apos;re hiring
            </h3>
            <p className="text-slate-400 text-sm font-body">
              Looking for exceptional automation engineers and AI architects to join the team.
            </p>
          </div>
          <a
            href="/contact"
            className="flex-shrink-0 inline-flex items-center gap-2 text-sm font-semibold text-blue-400 hover:text-blue-300 border border-blue-500/30 hover:border-blue-500/60 px-5 py-2.5 rounded-xl transition-all duration-200 hover:bg-blue-500/[0.05]"
          >
            <Globe size={14} />
            See open roles →
          </a>
        </motion.div>
      </div>
    </section>
  )
}
