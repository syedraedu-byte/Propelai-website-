'use client'

import { motion } from 'framer-motion'
import { Badge } from '@/components/ui/Badge'
import { GridBackground, GlowOrbs } from '@/components/effects/GridBackground'

export function AboutHero() {
  return (
    <section className="relative pt-36 pb-24 overflow-hidden">
      <GridBackground variant="dots" intensity="subtle" />
      <GlowOrbs />
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 70% 50% at 50% 0%, rgba(139,92,246,0.1), transparent)',
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-6"
        >
          <Badge variant="purple" dot>Our Story</Badge>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-5xl sm:text-6xl lg:text-7xl font-display font-800 tracking-tight text-white leading-[1.06] mb-6"
        >
          We exist to make
          <br />
          <span className="gradient-text">repetition extinct</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="text-slate-400 text-xl max-w-2xl mx-auto font-body leading-relaxed"
        >
          Propel AI was founded on a single belief: the highest-leverage thing
          any business can do is stop its best people from doing work that
          machines can do better.
        </motion.p>
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{ background: 'linear-gradient(to bottom, transparent, #050508)' }}
      />
    </section>
  )
}
