'use client'

import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { Badge } from '@/components/ui/Badge'

const milestones = [
  {
    year: 'Q1 2024',
    title: 'Founded',
    description:
      'Propel AI founded with a single thesis: production-grade AI automation for businesses that can\'t afford to wait years for results.',
    color: 'blue',
    dot: 'bg-blue-500',
    line: 'from-blue-500/50 to-purple-500/50',
  },
  {
    year: 'Q2 2024',
    title: 'First 10 Clients',
    description:
      'Deployed our first batch of CRM automations and AI chatbots for real estate and coaching clients. Proved the 72-hour deployment model.',
    color: 'purple',
    dot: 'bg-purple-500',
    line: 'from-purple-500/50 to-cyan-500/50',
  },
  {
    year: 'Q3 2024',
    title: 'Voice AI Launch',
    description:
      'Launched our AI voice agent service using Vapi.ai. First client handled 150+ calls/week autonomously within 30 days of go-live.',
    color: 'cyan',
    dot: 'bg-cyan-500',
    line: 'from-cyan-500/50 to-emerald-500/50',
  },
  {
    year: 'Q4 2024',
    title: '$1M Automated',
    description:
      'Crossed $1M in total client revenue processed through our automation systems. Expanded team with 3 senior AI architects.',
    color: 'green',
    dot: 'bg-emerald-500',
    line: 'from-emerald-500/50 to-amber-500/50',
  },
  {
    year: 'Q1 2025',
    title: '100 Clients',
    description:
      'Reached 100 active clients across India, UAE, and UK. Launched enterprise tier for operations-heavy organizations.',
    color: 'amber',
    dot: 'bg-amber-500',
    line: 'from-amber-500/50 to-blue-500/50',
  },
  {
    year: 'Today',
    title: 'Scaling Fast',
    description:
      'Powering 200+ businesses with AI automation. $10M+ in revenue touched. Building the most elite automation agency in Asia.',
    color: 'blue',
    dot: 'bg-gradient-to-br from-blue-500 to-purple-600',
    line: 'from-transparent to-transparent',
  },
]

export function Timeline() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <section ref={ref} className="relative py-20 overflow-hidden">
      <div className="max-w-4xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Badge variant="white" className="mb-5">✦ Our Journey</Badge>
          <h2 className="text-4xl sm:text-5xl font-display font-800 tracking-tight text-white mb-4 leading-[1.08]">
            From idea to <span className="gradient-text">industry leader</span>
          </h2>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-6 top-3 bottom-3 w-px bg-gradient-to-b from-blue-500/40 via-purple-500/30 to-transparent hidden sm:block" />

          <div className="flex flex-col gap-0">
            {milestones.map((m, i) => (
              <motion.div
                key={m.year}
                initial={{ opacity: 0, x: -30 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: i * 0.1 + 0.2 }}
                className="relative flex gap-6 sm:gap-8 pb-10 last:pb-0 group"
              >
                {/* Dot */}
                <div className="flex-shrink-0 flex flex-col items-center">
                  <div className={`w-3 h-3 rounded-full mt-1.5 flex-shrink-0 ${m.dot} shadow-[0_0_12px_rgba(59,130,246,0.5)] group-hover:scale-150 transition-transform duration-300`} />
                </div>

                {/* Content */}
                <div className="flex-1 pb-2">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-display font-700 tracking-widest uppercase text-slate-500">
                      {m.year}
                    </span>
                    {m.year === 'Today' && (
                      <span className="px-2 py-0.5 rounded-lg text-xs font-semibold bg-blue-500/10 border border-blue-500/25 text-blue-400">
                        Present
                      </span>
                    )}
                  </div>
                  <h3 className="text-white font-display font-700 text-lg mb-2 tracking-tight">
                    {m.title}
                  </h3>
                  <p className="text-slate-400 text-sm leading-relaxed font-body">
                    {m.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
