import type { Metadata } from 'next'
import { AboutHero } from './AboutHero'
import { Mission } from './Mission'
import { TeamSection } from './TeamSection'
import { Timeline } from './Timeline'
import { CTA } from '@/components/sections/CTA'

export const metadata: Metadata = {
  title: 'About — Our Mission, Vision & Team',
  description:
    'Learn about Propel AI — our mission to eliminate operational repetition, our founding story, and the team building the future of AI automation.',
}

export default function AboutPage() {
  return (
    <>
      <AboutHero />
      <Mission />
      <Timeline />
      <TeamSection />
      <CTA />
    </>
  )
}
